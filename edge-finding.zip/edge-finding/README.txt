For C Code:

INPUT:

Parameters of a simulated image. 

OUTPUT:

A 2-D matrix where each element corresponds to a derivative in the original map as per the Canny edge-finding algorithm. 
Values at each point are either -1, for a point determined not to be on an edge, 
or 0 - 15, depending on the direction of the gradient as described in the "sector wheel" in inline documentation in the matlab files and main.c.

GENERAL METHOD:
Generate a simulation using statistics gathered from sky-maps.
Apply derivative-map and gaussian filter.
Categorize the derivatives by "sector" of their direction, using 16 sectors. 
Each "sector" corresponds to one grid-direction, vertical horizontal or diagonal, one sign of the derivative, 
and one other grid-direction in which an edge could continue to account for curvature of less than 22.5 degrees per pixel.

For Matlab Code:

INPUT:

The "Sector Map" of the C code output.

OUTPUT:

A count of edges grouped by length in the image.

USE:

Distributions of edge-lengths should differ between images with and without objects. 
The differences may be used to guide closer study of images suspected of contianing objects.

GENERAL METHOD:
Trace the edges mimicking human edge-tracking behaviour.
Where there appears to be a branch, recursively follow both and add the longer branches to the trunk while counting th shorter ones separately.
