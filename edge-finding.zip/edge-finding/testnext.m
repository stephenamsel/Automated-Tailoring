function [long1 long2] = testnext(i,j,dist)
global sector

%A quick recap of sectors:	Gradient directions, line moves this way
    %					  12 11                 		 8 7
    %       	        13     10				        9    6
    %			      14         9				      10      5
    %			     15           8				     11        4
    %			      0	          7				     12        3
    %			       1         6				      13      2
    %					 2     5				       14    1
    %					   3 4               			15 0

%long1: for clockwise, long2: for counterclockwise
if sector(i,j)<2 %check down, down-right
    long1 = countpoint(i,j,i,j+1,dist);
    long2 = countpoint(i,j,i+1,j+1,dist);
end
if sector(i,j)==2 || sector(i,j)==3 %check down-right, right
    long2 = countpoint(i,j,i+1,j+1,dist);
    long1 = countpoint(i,j,i+1,j,dist);

end
if sector(i,j)==4 || sector(i,j)==5 % check right, up-right
    long1 = countpoint(i,j,i+1,j,dist);
    long2 = countpoint(i,j,i+1,j-1,dist);
end
if sector(i,j)==6 || sector(i,j)==7 %check up-right, up
    long1 = countpoint(i,j,i+1,j-1,dist);
    long2 = countpoint(i,j,i,j-1,dist);
end 
if sector(i,j)==8 || sector(i,j)==9 %check up, up-left
    long1 = countpoint(i,j,i,j-1,dist);
    long2 = countpoint(i,j,i-1,j-1,dist);
end 
if sector(i,j)==10 || sector(i,j)==11 %check up-left, left
    long1 = countpoint(i,j,i-1,j-1,dist);
    long2 = countpoint(i,j,i-1,j,dist);
end 
if sector(i,j)==12 || sector(i,j)==13 %check left, downleft 
    long1 = countpoint(i,j,i-1,j,dist);
    long2 = countpoint(i,j,i-1,j+1,dist);
end
if sector(i,j)==14 || sector(i,j)==15 %check downleft, down
    long1 = countpoint(i,j,i-1,j+1,dist);
    long2 = countpoint(i,j,i,j+1,dist);    
end

end