%line always moves 90-degrees counter-clockwise from gradient
%branchings handled in countpoint
%check previous point. Is it on a line?
%check for endpoint of already-checked line

%Recap of sectors:	Gradient directions, 		line moves this way
    %					  12 11                 		 8 7
    %       	        13     10				        9    6
    %			      14         9				      10      5
    %			     15           8				     11        4
    %			      0	          7				     12        3
    %			       1         6				      13      2
    %					 2     5				       14    1
    %					   3 4               			15 0


function [first] = firstpoint(i,j)
global outmap sector endpoints
first = 0;

%check previous point (go backwards)

if sector(i,j)<2 %check up, up-left
    if outmap(i,j-1)==0 && outmap(i-1,j-1)==0
        first = 1;
    end
end
if sector(i,j)==2 || sector(i,j)==3 %check up-left, left
    if outmap(i+1,j-1)==0 && outmap(i-1,j)==0
        first=1;
    end
end
if sector(i,j)==4 || sector(i,j)==5 % check left, down-left
    if outmap(i-1,j)==0 && outmap(i-1,j+1)==0
        first=1;
    end
end
if sector(i,j)==6 || sector(i,j)==7 %check down-left, down
    if outmap(i-1,j+1)==0 && outmap(i,j+1)==0
        first=1;
    end
end 
if sector(i,j)==8 || sector(i,j)==9 %check down, down-right
    if outmap(i,j+1)==0 && outmap(i+1,j+1)==0
        first=1;
    end
end 
if sector(i,j)==10 || sector(i,j)==11 %check down-right, right
    if outmap(i+1,j+1)==0 && outmap(i+1,j)==0
        first=1;
    end
end 
if sector(i,j)==12 || sector(i,j)==13 %check right, up-right 
    if outmap(i,j+1)==0 && outmap(i+1,j-1)==0
        first=1;
    end
end
    
if sector(i,j)==14 || sector(i,j)==15 %check up-right, up
    if outmap(i+1,j-1)==0 && outmap(i,j-1)==0
        first=1;
    end
    
end
%Check if already covered (should not happen, but still good to have a failsafe)
if endpoints(i,j) >= 1
    first = 0;
end