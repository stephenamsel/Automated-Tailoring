#!/bin/bash

cd /afs/umich.edu/user/s/a/samsel/Desktop/canny_matlab
for i in (1..324)
do
./canny
cp canny_outputs/out0 sectormap
mv canny_outputs/out0 canny_outputs/cannyout$i
matlab -nojvm -nodisplay -nosplash < edgecount.m >> histograms
done
