function [long0] = countpoint(a,b,r,q,dist)
global outmap sector edgenumber endpoints histogram first,

long0 = dist;
if mod(abs(sector(r,q)-sector(a,b)),16)<2 && outmap(r,q)==1 
   % if endpoints(a,b)<1 || first == 1
    long0 = long0 + 1;
    
    [long1 long2] = testnext(r,q,long0);
    
    if long1+long2==0
        endpoints(a,b)=edgenumber;
    end
    if long1>long2
        histogram(long1) = histogram(long1)+1;

        if long2 > long0
        histogram(long2-long0)=histogram(long2-long0)+1;

        end
    end
    if long2>=long1 && long2>0
        histogram(long2) = histogram(long2)+1;

        if long1 > long0
        histogram(long1-long0)=histogram(long1-long0)+1;

        end
    end

    endpoints(r,q)=edgenumber;
end
end



