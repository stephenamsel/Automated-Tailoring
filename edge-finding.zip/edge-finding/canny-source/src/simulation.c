/* simulation.c
 *
 * File containing main for the program "simulation" which generates a simulated
 * map of the CMB on small angular scales based on a file containing the observed Cl's.
 * Models indicate that temperature-effects from strings would add linearly to the temperature
 * from other effects (Gaussian effects of inflation).
 * Therefore, when necessary, two maps are produced with indices for position and entries for
 * temperature, then added. Otherwise only one such map is created.
 */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "global.h"
void breaksim(){
return;
}
/* main function of simulation */
matrix simulation(int window, double res, double Gmu, double string_p, int multiple, int with_strings, int with_junc, char *filename, double prob_junc, int run) {
	int i; // Counter
	vector Cl; // String, ang Gaussian Cls 
	matrix output, smap, gmap, instmap; // Various matrices
	//res = res * pow(2.0, 0.5);
	Cl = readcl(filename); //get Cls for the Gaussian contribution to the map
	
	/* Gather input parameters */

	/* Produce map with strings, if desired*/
	if (with_strings) {
		smap = genstringmap(window, res, Gmu, string_p, multiple, with_junc, prob_junc);
		//datamap(outs, smap, run);
	}
	//gmap = Matrix(window, window);

	/* Generate the Gaussian contribution to the map */
	gmap = gengaussianmap(Cl, window, res, &instmap); 
	/* Set output matrix depending on whether there are strings */
	output = Matrix(window, window);
	breaksim;
	if (with_strings) {
		for (i = 0; i < window * window; i++) {
/*Gaussian map is adjusted so that the output gives the correct CLs for low Ls, while maintaining the string-model */
			output.M[i][0] = smap.M[i][0] + gmap.M[i][0] * (1.0- 100000.0 * Gmu * string_p); // + instmap.M[i][0];
		}
	}
	else {
		for (i = 0; i < gmap.m * gmap.n; i++) {
			output.M[i][0] = gmap.M[i][0]; // + instmap.M[i][0];
		}
	}
	//printf("Successfully generated simulation\n");
	if (with_strings) fftw_free(smap.M);
	fftw_free(gmap.M);
	// fftw_free(instmap.M);
	return output;
}
