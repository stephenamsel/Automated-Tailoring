#include <stdio.h>
#include <string.h>
#include "global.h"

#define LEVELS 100

void psbreaker(){
return;
}

void psplot(matrix in, char inout, char *outname) {
	int i, j, k;
	double r, g, b;
	char filename[80], title[80];
	char fullfilename[] = "canny_outputs/";
	FILE *psout, *info;
	double max, hlev;
	int boxsize = 5, margin, left, bottom, top, right;
	psbreaker;
	sprintf(filename, "%s", outname);
	//if (inout == 'a') info = fopen("canny_outputs/in_filename.txt", "r");
	//if (inout == 'b') info = fopen("canny_outputs/out_filename.txt", "r");
	//printf("Enter name of postscript file output: ");
	//fscanf(info, "%s", filename);
	strcat(fullfilename, filename);
	//printf("Enter a title for the graph (80 character max.): ");
	/* I was thinking of changing the title to some standard like above, but it is not as necessary. I am also not quite certain about
	fclose(info); */
	if ((psout = fopen(fullfilename, "w")) == NULL) {
		fprintf(stderr, "Cannot open file\n");
		exit(-1);
	}
	
	margin = 50;
	left = margin;
	bottom = margin;
	top = margin + boxsize*in.m;
	right = margin + boxsize*in.n;
	fprintf(psout, "\%!PS-Adobe-2.0 EPSF-2.0\n");
	fprintf(psout, "\%\%BoundingBox: 0 0 %d %d\n", 2*margin + 55 + right + boxsize, 2*margin + 5 + boxsize*in.m);
	fprintf(psout, ".05 setlinewidth\n");
	max = findmax(in);
	for (i = 0; i < in.m; i++) {
		for (j = 0; j < in.n; j++) {
			for (k = -LEVELS/2; k < LEVELS/2; k++) {
				hlev = (double)LEVELS/2;
				if ((double)k/hlev * max <= in.M[j + i * in.n][0] && 
						in.M[j + i * in.n][0] <= (double)(k + 1)/hlev * max) {
					/*
					if ((double)k + 0.5 > 0.0) {
						r = 1.0/(hlev - 0.5) * ((double)k + 0.5);
					}
					else {
						r = 0;
					}
					g = -1.0/(hlev - 0.5) * fabs((double)k + 0.5) + 1.0;
					if ((double)k + 0.5 < 0.0) {
						b = -1.0/(hlev - 0.5) * ((double)k + 0.5);
					}
					else {
						b = 0;
					}
					*/
					r = 0.5/(hlev - 0.5) * ((double)k + 0.5) + 0.5;
					if ((double)k + 0.5 > 0.0) {
					  g = 1.0/(hlev - 0.5) * ((double)k + 0.5);
					}
				  else {
					  g = 0;
					}
					if ((double)k + 0.5 < 0.0) {
					  b = -1.0/(hlev - 0.5) * ((double)k + 0.5);
					}
				  else {
					  b = 0;
					}				
					fprintf(psout, "%G %G %G setrgbcolor\n", r, g, b);
					fprintf(psout, "newpath\n");
					fprintf(psout, "%d %d moveto\n", j * boxsize + left + 5, top - i * boxsize);
					fprintf(psout, "%d %d rlineto\n", boxsize, 0);
					fprintf(psout, "%d %d rlineto\n", 0, -boxsize);
					fprintf(psout, "%d %d rlineto\n", -boxsize, 0);
					fprintf(psout, "closepath\nfill\n");
					break;
				}
			}
			/*
			if (i % 5 == 0 && j % 5 == 0) {
				fprintf(psout, "0 0 0 setrgbcolor\n");
				fprintf(psout, "newpath\n");
				fprintf(psout, "%d %d moveto\n", (j + 5) * 5 + 40, 800 - (i + 5) * 5);
				fprintf(psout, "%d %d rlineto\n", -25, 0);
				fprintf(psout, "%d %d rlineto\n", 0, 25);
				fprintf(psout, "%d %d rlineto\n", 25, 0);
				fprintf(psout, "closepath\nstroke\n");
			}
			*/
		}
		if (i % 5 == 0) {
			fprintf(psout, "0 0 0 setrgbcolor\n");
			fprintf(psout, "/Times-Roman findfont\n");
			fprintf(psout, "8 scalefont\n");
			fprintf(psout, "setfont\n");
			fprintf(psout, "newpath\n");
			fprintf(psout, "%d %d moveto\n", left + i * boxsize + 5, bottom);
			fprintf(psout, "(%d) show\n", i);
			fprintf(psout, "%d %d moveto\n", left, top - i * boxsize - 4);
			fprintf(psout, "(%d) show\n", i);
		}
	}
	for (i = 0; i < in.m; i++) {
		for (j = 0; j < in.n; j++) {
			fprintf(psout, "0 0 0 setrgbcolor\n");
			fprintf(psout, "newpath\n");
			fprintf(psout, "%d %d moveto\n", (j + 1) * boxsize + left + 5, top - (i + 1) * boxsize);
			fprintf(psout, "%d %d rlineto\n", -boxsize, 0);
			fprintf(psout, "%d %d rlineto\n", 0, boxsize);
			fprintf(psout, "%d %d rlineto\n", boxsize, 0);
			fprintf(psout, "closepath\nstroke\n");
		}
	}
/*	fprintf(psout, "0 0 0 setrgbcolor\n");
	fprintf(psout, "/Times-Roman findfont\n");
	fprintf(psout, "8 scalefont\n");
	fprintf(psout, "setfont\n");
	fprintf(psout, "newpath\n");
	fprintf(psout, "%d %d moveto\n", left + 5, bottom - 10);
	fprintf(psout, "(%s) show\n", filename);
	fprintf(psout, "%d %d moveto\n", right + margin, top);
	fprintf(psout, "(%G) show\n", max);
	fprintf(psout, "1 1 0 setrgbcolor\n");
	fprintf(psout, "newpath\n");
	fprintf(psout, "%d %d moveto\n", right + margin + 50, top);
	fprintf(psout, "%d %d rlineto\n", boxsize, 0);
	fprintf(psout, "%d %d rlineto\n", 0, boxsize);
	fprintf(psout, "%d %d rlineto\n", -boxsize, 0);
	fprintf(psout, "closepath\nfill\n");
	fprintf(psout, "0 0 0 setrgbcolor\n");
	fprintf(psout, "%d %d moveto\n", right + margin, top - 10);
	fprintf(psout, "(0) show\n");
	fprintf(psout, ".5 0 0 setrgbcolor\n");
	fprintf(psout, "newpath\n");
	fprintf(psout, "%d %d moveto\n", right + margin + 50, top - 10);
	fprintf(psout, "%d %d rlineto\n", boxsize, 0);
	fprintf(psout, "%d %d rlineto\n", 0, boxsize);
	fprintf(psout, "%d %d rlineto\n", -boxsize, 0);
	fprintf(psout, "closepath\nfill\n");
	fprintf(psout, "0 0 0 setrgbcolor\n");
	fprintf(psout, "%d %d moveto\n", right + margin, top - 20);
	fprintf(psout, "(%G) show\n", -max);
	fprintf(psout, "0 0 1 setrgbcolor\n");
	fprintf(psout, "newpath\n");
	fprintf(psout, "%d %d moveto\n", right + margin + 50, top - 20);
	fprintf(psout, "%d %d rlineto\n", boxsize, 0);
	fprintf(psout, "%d %d rlineto\n", 0, boxsize);
	fprintf(psout, "%d %d rlineto\n", -boxsize, 0);
	fprintf(psout, "closepath\nfill\n"); */
	fprintf(psout, "showpage\n");
	fprintf(psout, "\%\%Trailer\n");
	fclose(psout);
}

double findmax(matrix in) {
	int i, j;
	double result;

	result = fabs(in.M[0][0]);
	for (i = 0; i < in.m; i++) {
		for (j = 1; j < in.n; j++) {
			if (fabs(in.M[j + i * in.n][0]) > result) {
				result = fabs(in.M[j + i * in.n][0]);
			}
		}
	}

	return result;
}
