
  #include "fftw3.h"
  #include <string.h>

#define N 15

typedef struct {
	fftw_complex *v;
	int length;
} vector;

typedef struct {
	fftw_complex *M;
	int m;
	int n;
} matrix;

typedef struct {
	int *M;
	int m;
	int n;
} imatrix;

vector Vector(int l);
matrix Matrix(int m, int n);
imatrix IMatrix(int m, int n);
void displayv(vector in);
void displaym(matrix in);
void writem(matrix in, char *filename);
vector fft(vector in);
vector invfft(vector in);
matrix fft2d(matrix in);
matrix invfft2d(matrix in);
matrix fft2dc2r(matrix in);
int getreply(int *boolean);
matrix convolution(matrix ipix, matrix filter);
matrix extend(matrix in, int rows, int cols);
int get_reply(int *boolean);
matrix gengaussianmap(vector Cl, int size, double res, matrix *instrumental);
void drawstring(int i, int j, matrix *map, double pixH, double Gmu);
matrix genstringmap(int num, double res, double Gmu, double string_p, int multiple, int with_junc, double prob_junc);
vector avg2_row(matrix input);		
matrix pixelize(char *filename);
int getfilesize(char *filename);
matrix canny(matrix ipix);
void filter(matrix ipix, matrix *omag, matrix *oang, double sigma);
matrix gaussianfilter(double s, int size);
void creategradientfilter(matrix *xgrad, matrix *ygrad);
//imatrix findsector(matrix iang, imatrix *sign);
matrix maxsuppression(matrix imag, matrix iang);
matrix hysteresis(matrix ipix, imatrix isec, double lower, double upper, double sigma, double res, double *factor);
double xfilter(double x, double y);
double yfilter(double x, double y);
void psplot(matrix in, char inout, char *outname);
double findmax(matrix in);
vector readcl(char *filename);
matrix readmaxima();
matrix simulation(int window, double res, double Gmu, double string_p, int multiple, int with_strings, int with_junc, char *filename, double prob_junc, int run);
void stringcount(matrix map, int *histogram, double *junc, imatrix isec);
int diragree(imatrix isec, int a, int b); 
	
void datamap(char* outfile, matrix data, int runnumb);
