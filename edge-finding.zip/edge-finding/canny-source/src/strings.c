/* strings.c
 *
 * Functions to deal with the simulation of a sky containing strings.  Constants
 * STRING_M and N are set in global.h and determine the number of strings per
 * horizon and the number of intervals between last scattering and the present
*/
#include <stdio.h>
#include <math.h>
#include "gaussian.h"
#include "global.h"

void drawjunction(int i, int j, matrix *map, double pixH, double Gmu);

/* Returns a map of the temperature anisotropy caused by strings */
matrix genstringmap(int window, double res, double Gmu, double string_p, int multiple, int with_junc, double prob_junc) {
	int i, j, k, x, y; // Counters
	double thetaH[N]; // Angular Hubble size at time N times, from last 
										// scattering to obserivation
	double theta, prob, rand; //prob_junc; Angular coverage, probability of strings, random 
														// number
	long idum = (long)time(NULL); // Seed for random number generation
	const double crtwo = pow(2.0, 1.0/3.0); // Cube root of 2, needed later
	matrix map, extmap[N]; // Output map, and extended map for each H time
	int n[N], pixH[N],  extwindow; // String number density, H pixel scale, total, size of extended map 
														 // pixel scale
	int halfsize; // Strings so far, half of the window size
	res = res / 60.0;
	theta = (double)window * res;
	map = Matrix(window, window);
//Windows and Linux don't get along very well. Watch out or theoretically impossible things will come and mess you up.
// YOU HAVE BEEN WARNED!!!!	
		/* Simulation technique from Moessner et al., "A Cosmic Strings Specific
		 * Signature on the Cosmic Microwave Background", Astrophys. J. 425 (1994) 
		 *
		 * Briefly, we break the interval from last scattering to now into N Hubble
		 * intervals, places strings randomly over the Hubble volume at each Hubble
		 * time, each randomly oriented with random velocity, and adds up the effect
		 * over all strings and all times */
		for (i = 0; i < N; i++) {
			if (i == 0) {
				thetaH[i] = 1.8;
			}
			else {
				thetaH[i] = crtwo * thetaH[i-1];
			}
			pixH[i] = thetaH[i] / res;
			n[i] = string_p * (1.0 + theta / thetaH[i]) * (1.0 + theta / thetaH[i]); // faster than pow, 2
			extwindow = 2 * pixH[i] + window;
			extmap[i] = Matrix(extwindow, extwindow);
				prob = (double)n[i] / ((double)extmap[i].m * (double)extmap[i].n);
				if (with_junc == 1) prob = prob / (1.0 + 2.0 * prob_junc);
				for (j = 0; j < extmap[i].m; j++) {
					for (k = 0; (k < extmap[i].n); k++) {
						rand = rand2(&idum);
						if (with_junc == 1 && rand < prob * prob_junc) drawjunction(j, k, &extmap[i], pixH[i], Gmu);
						else if (rand < prob) drawstring(j, k, &extmap[i], pixH[i], Gmu);
						
					}
				}
			halfsize = pixH[i] / 2;
			for (j = 0; j < window; j++) {
				for (k = 0; k < window; k++) {
					x = j + pixH[i] ;
					y = k + pixH[i] ;
					map.M[k + map.n * j][0] += extmap[i].M[y + extmap[i].n * x][0];
				}
			}
		}
//		printf("Successfully Generated String Map\n");
	/*	else {
		for (i = 0; i < map.m; i++) {
			map.M[i + map.n * i][0] = 4 * M_PI * Gmu * 0.15;
		}
		} */
	for (i = 0; i < N; i++) {
		fftw_free(extmap[i].M);
	}
	return map;
	
}
/* Draws a string centered at (i,j) of length pixH */
void drawstring(int i, int j, matrix *map, double pixH, double Gmu) {
	double angle, slope1, slope2, shifts, shiftc, r, beta; 
	// string angle with galactic horizontal, slope of strings, perpendicular to
	// string, vertical shift, horizontal shift, r, beta from paper */
	int m, n; // Counters
	const double vsgs = 0.15; // Velocity of string * relativistic gamma
	long idum = (long)time(NULL); // Seed for random number generation

	angle = rand2(&idum) * 2 * M_PI;
	slope1 = tan(angle);
	slope2 = - 1 / slope1;
	shifts = sin(angle);
	shiftc = cos(angle);
	r = rand2(&idum);
	beta = 4 * M_PI * Gmu * vsgs;


	/* Create boxes above and below string with same temperature shift */
	for (m = 0; m < (map->m); m++) {
		for (n = 0; n < (map->n); n++) {
			if (m > slope1 * (n - j) + i && 
					m < slope1 * (n - j + pixH * shifts) + i + pixH * shiftc &&
					m > slope2 * (n - j - pixH * shiftc) + i - pixH * shifts &&
					//m > slope2 * (n - j) + i - pixH * shifts &&
					m < slope2 * (n - j + pixH * shiftc) + i + pixH * shifts) {
				map->M[n + map->n * m][0] += beta * r;
			}
			else if (
					m < slope1 * (n - j) + i && 
					m > slope1 * (n - j - pixH * shifts) + i - pixH * shiftc &&
					m > slope2 * (n - j - pixH * shiftc) + i - pixH * shifts &&
					//m > slope2 * (n - j) + i - pixH * shifts &&
					m < slope2 * (n - j + pixH * shiftc) + i + pixH * shifts) {
				map->M[n + map->n * m][0] -= beta * r;
			}
		}
	}
}

void drawjunction(int i, int j, matrix *map, double pixH, double Gmu) {
	double angle, slope1, slope2, shifts, shiftc, r, beta; 
	// string angle with galactic horizontal, slope of strings, perpendicular to
	// string, vertical shift, horizontal shift, r, beta from paper */
	int m, n, k; // Counters
	const double vsgs = 0.15; // Velocity of string * relativistic gamma
	long idum = (long)time(NULL); // Seed for random number generation

	angle = rand2(&idum) * 2 * M_PI;
	for (k = 0; k < 2; k++){	
		slope1 = tan(angle); // slope of string
		slope2 = - 1 / slope1; // slope of string-path (perpendicualr to string)
		shifts = sin(angle);
		shiftc = cos(angle);
		r = rand2(&idum);
		beta = 4 * M_PI * Gmu * vsgs;
		if (k == 2) beta = -beta;
	/* Create boxes above and below string with same temperature shift */
	
		for (m = 0; m < (map->m); m++) {
			for (n = 0; n < (map->n); n++) {
				if (m > slope1 * (n - (j + pixH*shiftc)) + (i + pixH*shifts) && 
					m < slope1 * (n - (j + pixH*shiftc) + pixH * shifts) + (i + pixH*shifts) + pixH * shiftc &&
					m > slope2 * (n - (j + pixH*shiftc) - pixH * shiftc) + (i + pixH*shifts) - pixH * shifts &&
					m < slope2 * (n - (j + pixH*shiftc) + pixH * shiftc) + (i + pixH*shifts) + pixH * shifts) {
						map->M[n + map->n * m][0] += beta * r;
				}
				else if (
					m < slope1 * (n - (j + pixH*shiftc)) + (i + pixH*shifts) && 
					m > slope1 * (n - (j + pixH*shiftc) - pixH * shifts) + (i + pixH*shifts) - pixH * shiftc &&
					m > slope2 * (n - (j + pixH*shiftc) - pixH * shiftc) + (i + pixH*shifts) - pixH * shifts &&
					m < slope2 * (n - (j + pixH*shiftc) + pixH * shiftc) + (i + pixH*shifts) + pixH * shifts) {
						map->M[n + map->n * m][0] -= beta * r;
				}
			}
		}
	angle = angle + M_PI / 3;
	}
}
			
/* Calculates the average of the complex magnitudes of each row of a matrix
 * Needed to calculate the Cl's from strings */
vector avg2_row(matrix input) {
	int i, j;
	vector output;

	output = Vector(input.m);
	for (i = 0; i < input.m; i++) {
		for (j = 0; j < input.n; j++) {
			output.v[i][0] += input.M[j + input.n*i][0] * input.M[j + input.n*i][0] +
				input.M[j + input.n*i][1] * input.M[j + input.n*i][1];
		}
		output.v[i][0] /= input.n;
	}

	return output;
}

         
