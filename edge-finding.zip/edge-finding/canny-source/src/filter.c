#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "global.h"

/* filter
 *
 * Input: matrix image, pointers to output matrices: maps of magnitude and 
 * angle of gradient
 * Returns: None */ 
void filter(matrix ipix, matrix *omag, matrix *oang, double sigma) {
	int i, j; // Counters
	matrix ogradx, ogrady;
	int length = 1;
	double x, y, exponent;
	matrix gradientx, gradienty;

		
	i = 1;
	while (exp(-(double)i * (double)i / 2.0 / sigma / sigma) 
			>= 0.01) {
		length = length + 2;
		i++;
	}
	
	//printf("Applying filter...\n");	
	/* Create x and y filters that are gradients of Gaussians */
	gradientx = Matrix(length,length);
	gradienty = Matrix(length,length);
	for (i = 0; i < gradientx.m; i++) {
		for (j = 0; j < gradientx.n; j++) {

			x = (double)j - (double)((length - 1) / 2);
			y = - ((double)i  - (double)((length - 1) / 2));
			exponent = -(x*x + y*y)/2.0/sigma/sigma;
			gradientx.M[j + i * gradientx.n][0] = - 1.0/(2 * M_PI) / 
				pow(sigma, 4.0) * x *	exp(exponent);
			gradienty.M[j + i * gradienty.n][0] = - 1.0/(2 * M_PI) / 
				pow(sigma, 4.0) * y *	exp(exponent);
		}
	}
	//printf("Filter Length: %d\n", length);

	/* Pure gradient, for debugging
	
	gradientx = Matrix(3,3);
	gradienty = Matrix(3,3);
	for (i = 0; i < 3; i++) {
		gradientx.M[i + 3][0] = - i + 1;
		gradienty.M[1 + 3 * i][0] = - i + 1;
	}
	*/

	/* Apply filters */
	ogradx = convolution(ipix, gradientx);
	ogrady = convolution(ipix, gradienty);
		
	*omag = Matrix(ogradx.m, ogradx.n);
	*oang = Matrix(ogradx.m, ogradx.n);
	
	/* Set output magnitude and angle of gradient */
	for (i = 0; i < omag->m * omag->n; i++) {
		omag->M[i][0] = sqrt(ogradx.M[i][0] * ogradx.M[i][0] + ogrady.M[i][0] *	
				ogrady.M[i][0]);
		oang->M[i][0] = atan2(ogrady.M[i][0], ogradx.M[i][0]) * 180/M_PI;
	}
	
	fftw_free(ogradx.M);
	fftw_free(ogrady.M);
	fftw_free(gradientx.M);
	fftw_free(gradienty.M);
	//printf("Successfully applied filter\n");
}	
