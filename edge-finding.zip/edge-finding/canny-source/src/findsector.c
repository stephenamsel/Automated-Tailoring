#include <stdio.h>
#include <stdlib.h>
#include "global.h"

/* findsector
 *
 * Input: Gradient angle matrix
 * Returns: Integer matrix containing sector corresponding to each angle
 * Sector 1: -22.5 deg < theta < 22.5 deg or -180 deg < theta < 157.5 deg or
 * 157.5 deg < theta < 180 deg
 * Sector 2: 22.5 deg < theta < 67.5 deg or -157.5 deg < -112.5 deg
 * Sector 3: 67.5 deg < 112.5 deg or -112.5 deg < theta < -67.5 deg
 * Sector 4: 112.5 deg < 157.5 deg or -67.5 deg < theta < 12.5 deg
 * This classification is necessary for non-maximum suppression and hysteresis
 * */
imatrix findsector(matrix iang, imatrix *sign) {
	int i; // Coutner
	imatrix osec; // Output, to be returned
	int nsec[4]; // Counts the number of pixels in each sector, for debugging
	osec = IMatrix(iang.m, iang.n);
	nsec[0] = 0;
	nsec[1] = 0;
	nsec[2] = 0;
	nsec[3] = 0;

	for (i = 0; i < iang.m * iang.n; i++) {
		if ((iang.M[i][0] >= -22.5 && iang.M[i][0] <= 22.5) ||
				(iang.M[i][0] >= -180 && iang.M[i][0] <= -157.5) ||
				(iang.M[i][0] >= 157.5 && iang.M[i][0] <= 180)) {
			osec.M[i] = 1;
			(nsec[0])++;
		}
		if ((iang.M[i][0] > 22.5 && iang.M[i][0] < 67.5) ||
				(iang.M[i][0] > -157.5 && iang.M[i][0] < -112.5)) {
			osec.M[i] = 2;
			(nsec[1])++;
		}
		if ((iang.M[i][0] >= 67.5 && iang.M[i][0] <= 112.5) ||
				(iang.M[i][0] >= -112.5 && iang.M[i][0] <= -67.5)) {
			osec.M[i] = 3;
			(nsec[2])++;
		}
		if ((iang.M[i][0] > 112.5 && iang.M[i][0] < 157.5) ||
				(iang.M[i][0] > -67.5 && iang.M[i][0] <= -22.5)) {
			osec.M[i] = 4;
			(nsec[3])++;
		}
		if ((iang.M[i][0] >= -22.5 && iang.M[i][0] <= 22.5 ) ||
			(iang.M[i][0] > 22.5 && iang.M[i][0] < 67.5) ||
		(iang.M[i][0] >= 67.5 && iang.M[i][0] <= 112.5) ||
		(iang.M[i][0] > 112.5 && iang.M[i][0] < 157.5)) sign->M[i] = 1;

		if ((iang.M[i][0] >= -180 && iang.M[i][0] <= -157.5) ||
			(iang.M[i][0] >= 157.5 && iang.M[i][0] <= 180) ||
		(iang.M[i][0] > -157.5 && iang.M[i][0] < -112.5) ||
		(iang.M[i][0] >= -112.5 && iang.M[i][0] <= -67.5) ||
		(iang.M[i][0] > -67.5 && iang.M[i][0] <= -22.5)) sign->M[i] = -1;

	}
	//printf("Sucessfully determined edge directions\n");
	printf("%d, %d, %d, %d\n",nsec[0],nsec[1],nsec[2],nsec[3]);
	
	return osec;
}
