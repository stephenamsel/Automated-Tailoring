#include <stdio.h>
#include <stdlib.h>
#include "global.h"
double test(imatrix isec, matrix opix, int prea, int preb, int a, int b);
double checkhorvert(int prea, int preb, imatrix isec, matrix opix, int a, int b, int predir);
double checkdiag(int prea, int preb, imatrix isec, matrix opix, int a, int b, int predir);
double checkpoint(int prea, int preb, imatrix isec, matrix opix, int a, int b, int q, int r, int predir);

int breakhys(){
return 0; }

matrix hysteresis(matrix ipix, imatrix isec, double lower, double upper, double sigma, double res, double *factor) {
	int i, j, k;
	double max; // Upper and lower thresholds
	matrix opix;
	int countsec[4];
	countsec[0] = 0; countsec[1] = 0; countsec[2] = 0; countsec[3] = 0; 
	

	max = findmax(ipix);
/*
Applying tabulated data for "max": These are the average maximum values found in a series of simulations with only a Gaussian component in the CMB. The standard deviations of these means were ~ 1% of their values. The tabulated data are used to avoid having separate normalization constants for cases with and without strings. If that were permitted, strings would not be seen because the higher maximum gradient (normalization factor) in maps containing them would set higher thresholds for visibility than maps without them, negating the effect of the higher gradients which they cause and which are the signal for which the Canny algorithm is intended to test.
*/
	/* if(sigma == 1.75){
	if(res == 8.0) max = 
	if(res == 9.0) max = 
	if(res == 10.0) max = 
	}*/
	
	if(sigma == 1.25){
	if(res == 8.0) max = 0.0000541877;
	if(res == 9.0) max = 0.0000538314;
	if(res == 10.0) max = 0.0000547023;
	}

	if(sigma == 1.0){
	if(res == 8.0) max = 0.000067265;
	if(res == 9.0) max = 0.0000680882;
	if(res == 10.0) max = 0.0000695249;
	}

	if(sigma == 1.5){
	if(res == 8.0) max = 0.0000540998;
	if(res == 9.0) max = 0.0000462224;
	if(res == 10.0) max = 0.0000441797;
	}

	if(sigma == 1.75){

	if(res == 8.0) max = 0.0000384967;
	if(res == 9.0) max = 0.0000379177;
	if(res == 10.0) max = 0.0000359202;
	}
	
	if(sigma == 2.0){

	if(res == 8.0) max = 0.0000306748;
	if(res == 9.0) max = 0.0000308508;
	if(res == 10.0) max = 0.0000306748;
	}

	upper = upper / 100.0 * max;
	lower = lower / 100.0 * max;
//	printf("%g \n", max);
	opix = Matrix(ipix.m, ipix.n);
	*factor = max;
/* 
Declaring gradients above the upper threshold to be on edges ("1"s), gradients below the lower threshold to be off edges ("0"s), and point between them to be undetermined ("0.5"s)
*/
	for (i = 0; i < opix.m; i++) {
		for (j = 0; j < opix.n; j++) {
			if (ipix.M[j + i * opix.n][0] <= lower)
				opix.M[j + i*opix.n][0] = 0.0;
			else if (ipix.M[j + i * opix.n][0] > upper)
				opix.M[j + i*opix.n][0] = 1.0;
			else
				opix.M[j + i*opix.n][0] = 0.5;
			if (ipix.M[j + i * opix.n][0] > lower){
				k = isec.M[j + i * opix.n] % 8 ;
				//countsec[k] ++ ;
			}
		}
	}

	//printf(" FILTERED SECTORS: %d, %d, %d, %d\n",countsec[0],countsec[1],countsec[2],countsec[3]);

/* 
Cycling through all points on the map and determining whether indeterminate points are on edges. Each point (i, j) is taken to be a "base-point" from which it is tested whether or not an edge can be found. Those which are found to be on edges are marked as "0.75" and those not are marked as "0". The "0.75" is used so as to avoid avoid false-positives where later points are only conneced to earlier points which lie between the thresholds and are marked as being on lines, but not points above the upper threshold. This is possible due to the demand for low curvature of the edges. (The 0.75 point may match, but the point beyond it may demand too sharp a curve in the line to do so.)

"Predir" is passed independently to avoid calling the same memory location in two functions at once, which causes a crash, I think. It is passed by value, so it uses a different memory-location each time.
*/

	for (i = 0; i < opix.m; i++) {
	for (j = 0; j < opix.n; j++) {
		if (opix.M[j + i*opix.n][0] == 0.5){
			if (test(isec, opix, i, j, i, j) == 1) opix.M[j + i*opix.n][0] = 0.75;
		}
	}
	}

	for (i = 0; i < opix.m * opix.n; i++){
	if (opix.M[i][0] == 0.75) opix.M[i][0] = 1.0;
	if (opix.M[i][0] == 0.5) opix.M[i][0] = 0.0;
	}

return opix;
}

/*
Tests a point which has just been checked and found to be intermediate. Determines which direction to go next.
*/
double test(imatrix isec, matrix opix, int prea, int preb, int a, int b){
	double out = 0.0;
	out = checkhorvert(prea, preb, isec, opix, a, b, isec.M[preb + prea*isec.n]);
	if (out == 0.0) out = checkdiag(prea, preb, isec, opix, a, b, isec.M[preb + prea*isec.n]);

	return out;
}

/*
Choice of new point to check:

All extensions wil be strictly away from the previous point on the edge. The ">=" and "<=" are drawn for the extension from the initial point (i, j) where the point from which the line is extending and the previous point are taken to be the same (i, j). In this case both directions along the corresponding line are checked.
*/
//Check in the horizontal or vertical direction corresponding to the sector of the previous point tested
double checkhorvert(int prea, int preb, imatrix isec, matrix opix, int a, int b, int predir){
	int q, r, breakvar;
	double out = 0.0;
	if((isec.M[b + a*opix.n]) % 8 > 1 && (isec.M[b + a*opix.n]) % 8 < 6){
		if (preb >= b){
			r = b - 1;
			q = a;
			out = checkpoint(prea, preb, isec, opix, a, b, q, r, predir);
		}
		if (preb <= b){
			r = b + 1;
			q = a;
			out = checkpoint(prea, preb, isec, opix, a, b, q, r, predir);
		}
	} else{
		if (prea >= a){
			q = a - 1;
			r = b;
			out = checkpoint(prea, preb, isec, opix, a, b, q, r, predir);
		}
		if (prea <= a){
			q = a + 1;
			r = b;
			out = checkpoint(prea, preb, isec, opix, a, b, q, r, predir);
		}
	}
breakvar = breakhys();
//	free(q);
//	free(r);
	return out;
}

// check in the diagonal direction corresponding to the sector of the previous point tested, like checkhorvert
double checkdiag(int prea, int preb, imatrix isec, matrix opix, int a, int b, int predir){
	int q, r;
	double out = 0.0;
	if ((isec.M[b + a*opix.n]) % 8 < 4){
		if (a+b <= prea+preb ){
			q = a - 1; 
			r = b - 1;
			out = checkpoint(prea, preb, isec, opix, a, b, q, r, predir);
		}
		if (a+b >= prea+preb ){
			q = a + 1;
			r = b + 1;
			out = checkpoint(prea, preb, isec, opix, a, b, q, r, predir);
		}
	}else {
		if (a-b <= prea-preb ){
			q = a - 1; 
			r = b + 1;
			out = checkpoint(prea, preb, isec, opix, a, b, q, r, predir);
		}
		if (a-b >= prea-preb ){
			q = a + 1;
			r = b - 1;
			out = checkpoint(prea, preb, isec, opix, a, b, q, r, predir);
		}
	}
//	free(q); free(r);
	return out;
}

/* 
Checks the indicated point for value and directional agreement with both points (i, j) and the previous checked point). The diragree is in "global.c", prototyped in "global.h", and checks that the sectors at two points differ by no more than 1 (limiting the amount by which a line can change direction and allowing differentiation between wiggles and T-junctions).
It first checks to make sure that it has not run over the edge of the image. 
If this condition is met, it then checks for directional agreement between the point to be ckecked and both the previous point on the line (a, b) and the one before that (prea, preb) in order constrain the permitted curvature.
If both conditions are met, it then it checks the value of the next point. A "1" returns a "1" all the way up the line, confirming the base-point as being on a line. A "0" returns a "0" up the line, marking the base-point as not on a line. A "0.5" or "0.75" gets the new point tested and made into the "previous point", (a, b) in "test" for another set of checks, and likewise makes the current (a, b) into the new (prea, preb).
*/

double checkpoint(int prea, int preb, imatrix isec, matrix opix, int a, int b, int q, int r, int predir){
double out = 0.0;
	if (r < opix.n && r >= 0 && q < opix.m && q >= 0){
		if ( abs(isec.M[r + q * opix.n] - predir) < 2 && diragree(isec, b + a*opix.n, r + q * opix.n) ){
		out = opix.M[q * opix.n + r][0];
		if (out == 0.5 || out == 0.75) out = test(isec, opix, a, b, q, r);
		}
	}
	return out;
}