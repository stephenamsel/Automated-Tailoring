/*
Prints the data of the temperature maps to a file.  It writes the data in
blocks of 15 columns.  Each column corresponds to a row of the data map.  After
the first 15 rows of data are printed in 15 columns in the output file, the
next 15 rows are then printed underneath. 
*/

#include<stdio.h>
#include"global.h"

void datamap(char* outfile, matrix data, int runnumb){
    FILE *outmap;
    char *run;
    int i, j, k, col, remain;
    sprintf(run,"%d", runnumb);//convert runnumb to char (run)
    sprintf(outfile, "canny_outputs/%s", outfile);
    strcat(outfile, run);
      outmap = fopen(outfile, "w");

      remain = data.m;
    for (k = 0; k < data.m / 15 + 1; k++){
    if(remain < 15){
      col = remain;
    }else col = 15;
		    for (j = 0; j < data.n; j++){
 		      for (i = 0; i < col; i++){
			fprintf(outmap, "%lf ", data.M[j*data.m + k*15 + i][0]);
		      }		 
			fprintf(outmap, "/n");
		    }
    remain = remain - 15;
		    
    }
    fclose(outmap);
}
