/* readmaxima.c
 *
 * Input: MAXIMA FITS file
 * Return: Temperature anisotropy map in rectangular grid
 *
 * Extracts the right ascension, declenination, and termperature anisotropy from
 * a MAXIMA fits file, normalizes and uses linear interpolation to place the
 * anisotropy into a 60x60 pixel grid */

#include <string.h>
#include <stdio.h>
#include "fitsio.h"
#include "global.h"

#define STARTX 225.0
#define STARTY 54.1

matrix readmaxima() {
	fitsfile *file; // FITS file pointer, defined in fitsio.h
	int status = 0; // CFITSIO status value MUST be initialized to zero
	char filename[80];
	int hdunum, hdutype, ncols, coltype;
	long width;
	long m, nrows;
	int i, j, k;
	double *ra, *dec, *dt;
	matrix x, y, vals, output;
	int imax = 1, jmax = 0, curmax = 0, iinit = 0;
	double a;
	FILE *position_file;

	printf("Enter path to MAXIMA FITS file:\n");
	scanf("%s", filename);
	
	if (!ffopen(&file, filename, READONLY, &status)) {
		/* Make sure that the portion dealt with is a table */
    if ( fits_get_hdu_num(file, &hdunum) == 1 )
			fits_movabs_hdu(file, 2, &hdutype, &status);
		else 
			fits_get_hdu_type(file, &hdutype, &status);
		if (hdutype == IMAGE_HDU) 
      fprintf(stderr,"Error: this program only reads tables, not images\n");
    else {
			/* Get size of table */
			fits_get_num_cols(file, &ncols, &status);
			fits_get_coltype(file, 1, NULL, &nrows, NULL, &status);
		
			/* Read data */
			ra = (double *)malloc(sizeof(double) * nrows);
			fits_read_col(file, TDOUBLE, 1, 1, 1, nrows, NULL, ra, NULL, &status);
			fits_get_coltype(file, 2, &coltype, &nrows, &width, &status);
			dec = (double *)malloc(sizeof(double) * nrows);
			fits_read_col(file, TDOUBLE, 2, 1, 1, nrows, NULL, dec, NULL, &status);
			fits_get_coltype(file, 3, &coltype, &nrows, &width, &status);
			dt = (double *)malloc(sizeof(double) * nrows);
			fits_read_col(file, TDOUBLE, 3, 1, 1, nrows, NULL, dt, NULL, &status);
			position_file = fopen("position.txt", "w");
			for (i = 0; i < nrows; i++) {
				fprintf(position_file, "%G\t%G\t%G\n", ra[i], dec[i], dt[i]);
			}
			fclose(position_file);
			/* Figure out how big a matrix is necessary to store the data
			 * Note that in the MAXIMA data, there are aligned rows, but the right
			 * ascensions are NOT aligned.  This does not yet attempt to align them,
			 * merely to sort them by declination */
			for (m = 0; m < nrows - 1; m++) {
				if (dec[m] - dec[m+1] != 0) {
					imax++;
					curmax++;
					if (curmax > jmax) {
						jmax = curmax;
					}
					curmax = 0;
				}
				else {
					curmax++;
				}
			}

			/* Now, put the data into matrices */
			printf("%d, %d\n", imax, jmax);
			x = Matrix(imax, jmax);
			y = Matrix(imax, jmax);
			vals = Matrix(imax, jmax);
			m = 0;
			for (i = 0; i < imax; i++) {
				j = 0;
				do {
					x.M[j + i * jmax][0] = (double)ra[m];
					y.M[j + i * jmax][0] = (double)dec[m];
					vals.M[j + i * jmax][0] = (double)dt[m]/1000000.0/2.725;
					j++;
					m++;
				} while (dec[m] - dec[m-1] == 0);
			}

			/* Finally, use linear interpolation to get manageable rectangular grid */
			i = 0;
			while (STARTY - y.M[i * jmax][0] > 0.01) { 
				i++;
			}
			iinit = i;
			output = Matrix(60,60);
			for (i = 0; i < 60; i++) {
				for (j = 0; j < 60; j++) {
					k = 0;
					while (x.M[k + (i + iinit) * jmax][0] < STARTX + j * 8.0/60.0) {
						k++;
					}
					a = (STARTX + (double)j * 8.0/60.0 - 
							x.M[k - 1 + (i + iinit) * jmax][0]) /
						(x.M[k + (i + iinit) * jmax][0] - 
						 x.M[k - 1 + (i + iinit) * jmax][0]);
					output.M[j + i * 60][0] = a * vals.M[k - 1 + (i + iinit) * jmax][0] +
						(1.0 - a) * vals.M[k + (i + iinit) * jmax][0];
				}
			}
		}	
	}
	if (status) fits_report_error(stderr, status); /* print any error message */
	fftw_free(x.M);
	fftw_free(y.M);
	fftw_free(vals.M);
	free(ra);
	free(dec);
	free(dt);
	return output;
}
