/* fft.c
 *
 * Very important set of functions that go with the defined data types vector
 * and matrix, including functions to initialize them, display them, write them
 * to file and perform fft's on them (their main purpose) */
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "global.h"

/* Initialize a vector of length l */
vector Vector(int l) {
	int i; // Counter
	vector result; // Initialized output

	result.length = l;
	result.v = fftw_malloc(sizeof(fftw_complex) * result.length);
	
	for (i = 0; i < result.length; i++) {
		result.v[i][0] = 0;
		result.v[i][1] = 0;
	}

	return result;
}

/* Initialize an mxn matrix */
matrix Matrix(int m, int n) {
	int i; // Counter
	matrix result; // Initialized output

	result.m = m;
	result.n = n;
	result.M = fftw_malloc(sizeof(fftw_complex) * result.m * result.n);

	if (result.M == NULL) {
		printf("Memory allocation error\n");
		exit(-1);
	}	
	for (i = 0; i < result.m * result.n; i++) {
		result.M[i][0] = 0;
		result.M[i][1] = 0;
	}
	
	return result;
}

imatrix IMatrix(int m, int n) {
	int i;
	imatrix result;

	result.m = m;
	result.n = n;
	result.M = fftw_malloc(sizeof(int) * result.m * result.n);
	
	if (result.M == NULL) {
		printf("Memory allocation error\n");
		exit(-1);
	}
	
	for (i = 0; i < result.m * result.n; i++) {
		result.M[i] = 0.0;
		result.M[i] = 0.0;
	}
	
	return result;
}

/* Display a vector to stdout, labelling each entry */
void displayv(vector in) {
	int i; // Counter

	for (i = 0; i < in.length; i++) {
		if ((in.v[i][0] != 0 && in.v[i][1] == 0) || 
				(in.v[i][0] == 0 && in.v[i][1] == 0)) {
			printf("%d\t%G\n", i, in.v[i][0]);
		}
		else if (in.v[i][0] == 0 && in.v[i][1] != 0) {
			printf("%d\t%G i\n", i, in.v[i][1]);
		}
		else {
			printf("%d\t%G + %Gi\n", i, in.v[i][0], in.v[i][1]);
		}
	}
	printf("\n");
}

/* Display a matrix to stdout, labelling each entry */
void displaym(matrix in) {
	int i, j; // Counters
	
	for (i = 0; i < in.m; i++) {
		for (j = 0; j < in.n; j++) {
			if ((in.M[j + in.n * i][0] != 0 && in.M[j + in.n * i][1] == 0) || 
					(in.M[j + in.n * i][0] == 0 && in.M[j + in.n * i][1] == 0)) {
				printf("%d\t%d\t%G\n", i, j, in.M[j + in.n * i][0]);
			}
			else if (in.M[j + in.n * i][0] == 0 && in.M[j + in.n * i][1] != 0) {
				printf("%d\t%d\t%G i\n", i, j, in.M[j + in.n * i][1]);
			}
			else {
				printf("%d\t%d\t%G + %Gi\n", i, j, in.M[j + in.n * i][0], 
						in.M[j + in.n * i][1]);
			}
		}
	}
	printf("\n");
}

/* Write a matrix to a file whose name is specified by filename */
void writem(matrix in, char *filename) {
	int i, j; // Counters
	FILE *ofile; // Output file

	if ((ofile = fopen(filename, "w")) == NULL) {
		printf("Error reading output file\n");
		exit(-1);
	}
	
  for (i = 0; i < in.m; i++) {
		for (j = 0; j < in.n; j++) {
		  if ((in.M[j + in.n * i][0] != 0 && in.M[j + in.n * i][1] == 0) ||
		      (in.M[j + in.n * i][0] == 0 && in.M[j + in.n * i][1] == 0)) {
				fprintf(ofile, "%d\t%d\t%G\n", i, j, in.M[j + in.n * i][0]);
	    }
	    else if (in.M[j + in.n * i][0] == 0 && in.M[j + in.n * i][1] != 0) {
				fprintf(ofile, "%d\t%d\t%G i\n", i, j, in.M[j + in.n * i][1]);
			}
			else {
			  fprintf(ofile, "%d\t%d\t%G + %Gi\n", i, j, in.M[j + in.n * i][0],
			      in.M[j + in.n * i][1]);
			}
		}
	}
	
	fclose(ofile);
}

/* Returns the 1d complex fft of a vector */
vector fft(vector in) {
	int i;
	vector newin, out; // Counter
	fftw_plan plan; // plan for fftw

	newin = Vector(in.length);
	out = Vector(in.length);
	plan = fftw_plan_dft_1d(newin.length, newin.v, out.v, FFTW_FORWARD, FFTW_MEASURE);
	for (i = 0; i < newin.length; i++) {
		newin.v[i][0] = in.v[i][0];
		newin.v[i][1] = in.v[i][1];
	}
	fftw_execute(plan);
	fftw_destroy_plan(plan);

	return out;
}

/* Returns the 1d complex inverse fft of a vector */
vector invfft(vector in) {
	int i; // Counter
	vector out; // Output vector
	fftw_plan plan; // plan for fftw

	out = Vector(in.length);
	plan = fftw_plan_dft_1d(in.length, in.v, out.v, FFTW_FORWARD, FFTW_MEASURE);
	fftw_execute(plan);
	fftw_destroy_plan(plan);

	/* Adjust the normalization, since fftw doesnt */
	for (i = 0; i < out.length; i++) {
		out.v[i][0] /= out.length;
		out.v[i][1] /= out.length;
	}

	return out;
}

/* Returns the 2d complex fft of a matrix */
matrix fft2d(matrix in) {
	int i; // Counter
	matrix newin, out; // For some reason, the input must be copied first to a new
										 // matrix, called newin
	fftw_plan plan; // plan for fftw

	newin = Matrix(in.m, in.n);
	out = Matrix(in.m, in.n);

	plan = fftw_plan_dft_2d(newin.m, newin.n, newin.M, out.M, FFTW_FORWARD, FFTW_MEASURE);
	
	/* Copy the input matrix to a new matrix */
	for (i = 0; i < newin.m * newin.n; i++) {
		newin.M[i][0] = in.M[i][0];
		newin.M[i][1] = in.M[i][1];
	}
	fftw_execute(plan);
	fftw_destroy_plan(plan);
	fftw_free(newin.M);

	return out;
}

/* Returns the 2d complex fft of a matrix */
matrix invfft2d(matrix in) {
	int i; // Counter
	matrix newin, out; // See fft2d for explanation of newin
	fftw_plan plan; // plan for fftw

	newin = Matrix(in.m, in.n);
	out = Matrix(in.m, in.n);

	plan = fftw_plan_dft_2d(newin.m, newin.n, newin.M, out.M, FFTW_BACKWARD, FFTW_MEASURE);
	for (i = 0; i < newin.m * newin.n; i++) {
		newin.M[i][0] = in.M[i][0];
		newin.M[i][1] = in.M[i][1];
	}
	fftw_execute(plan);
	fftw_destroy_plan(plan);
	fftw_free(newin.M);

	for (i = 0; i < out.m * out.n; i++) {
		out.M[i][0] /= out.m;
		out.M[i][1] /= out.m;
	}
	return out;
}

matrix fft2dc2r(matrix in) {
	int i; // Counter
	double *realout;
	matrix newin, out; // For some reason, the input must be copied first to a new
										 // matrix, called newin
	fftw_plan plan; // plan for fftw

	newin = Matrix(in.m, in.n);
	out = Matrix(in.m, 2*(in.n - 1));
	realout = fftw_malloc(sizeof(double) * out.m * out.n);

	plan = fftw_plan_dft_c2r_2d(out.m, out.n, newin.M, realout, FFTW_MEASURE);
	
	/* Copy the input matrix to a new matrix */
	for (i = 0; i < newin.m * newin.n; i++) {
		newin.M[i][0] = in.M[i][0];
		newin.M[i][1] = in.M[i][1];
	}
	fftw_execute(plan);
	fftw_destroy_plan(plan);
	fftw_free(newin.M);

	for (i = 0; i < out.m * out.n; i++) {
		out.M[i][0] = realout[i] / pow(out.m * out.n,0.5);
	}
	free(realout);
	return out;
}

int getreply(int *boolean) {
	char buffer[80];

	scanf("%s", buffer);
	if (buffer[0] == 'y') {
		*boolean = 1;
		return 0;
	}
	else if (buffer[0] == 'n') {
		*boolean = 0;
		return 0;
	}
	else {
		return 1;
	}
}

int diragree(imatrix isec, int a, int b){
	int out = 0;
	if (abs(isec.M[a] - isec.M[b]) < 2) out = 1;

	return out;
}