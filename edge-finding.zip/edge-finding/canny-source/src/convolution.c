/* convolution.c
 *
 * Functions to convolute an image with a filter using a fast Fourier transform.
 * This turns out to be faster than direct convolution.  */
#include <stdio.h>
#include <stdlib.h>
#include "global.h"

/* convolution
 *
 * Input: image matrix, filter matrix
 * Returns: matrix convolution of image with filter, filter * input */
matrix convolution(matrix input, matrix filter) {
	int i, j; // Counters
	matrix output; // Result of convolution to be returned
	matrix Finput, Foutput, Ffilter; // Fourier transforms of matrices 
	matrix largeout; // Extended version of the output obtained after inv. FFT
	
	/* Make sure the filter is smaller */
	if (input.n < filter.n || input.m < filter.m) {
		fprintf(stderr,"Error: wrong order for convolution\n");
		exit(-1);
	}

	/* Extend the input matrices to get proper output size  */
	Finput = fft2d(extend(input, input.m + filter.m - 1, input.n + filter.n - 1));
	Ffilter = fft2d(extend(filter, input.m + filter.m - 1, 
				input.n + filter.n - 1));

	/* Multiply term by term */
	Foutput = Matrix(Finput.m, Finput.n);
	for (i = 0; i < Foutput.m * Foutput.n; i++) {
		Foutput.M[i][0] = Finput.M[i][0] * Ffilter.M[i][0] - Finput.M[i][1] *	
			Ffilter.M[i][1];
		Foutput.M[i][1] = Finput.M[i][0] * Ffilter.M[i][1] + Finput.M[i][1] *	
			Ffilter.M[i][0];
	}

	/* Invert to get result */
	largeout = invfft2d(Foutput);

	output = Matrix(input.m - filter.m + 1, input.n - filter.n + 1);

	/* Set the output matrix equal to the appropriate parts of inv. FFT */
	for (i = 0; i < output.m; i++) {
		for (j = 0; j < output.n; j++) {
			output.M[j + output.n * i][0] = largeout.M[j + filter.n - 1 + largeout.n *
			(i + filter.m - 1)][0];
			output.M[j + output.n * i][1] = largeout.M[j + filter.n - 2 + largeout.n *
			(i + filter.m - 2)][1];
		}
	}
	fftw_free(Finput.M);
	fftw_free(Foutput.M);
	return output;
}
	
/* extend
 *
 * Input: matrix to be extended, new dimensions
 * Returns: matrix with new dimensions and entries the same as input */
matrix extend(matrix input, int rows, int cols) {
	int i, j;
	matrix output;

	output = Matrix(rows, cols);
	for (i = 0; i < output.m; i++) {
		for (j = 0; j < output.n; j++) {
			if (i < input.m && j < input.n) {
				output.M[j + output.n * i][0] = input.M[j + input.n * i][0];
				output.M[j + output.n * i][1] = input.M[j + input.n * i][1];
			}
		}
	}
	return output;
}
