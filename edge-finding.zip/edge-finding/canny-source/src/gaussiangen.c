/* gaussiangen.c
 *
 * Function to generate a Gaussian map from Cl's */
#include <stdio.h>
#include <math.h>
#include <time.h>
#include "gaussian.h"
#include "global.h"

void breaker(){
return;
} // for breakpoints for debugging

matrix inst(int size, int umax, double res, vector S);

/* gaussiangen
 *
 * Input: vector containing Cl's, size of map to be generated, resolution of map
 * in arcminutes. This algorithm functions only up to a resolution determined by the maximum l value in the vector.
 * In simulation, only values up to 3000 were available so only resolutions down to 7.2 could be tested (res > 21600/l(max), 21600 arcminutes = 2pi radians.
 */
matrix gengaussianmap(vector Cl, int size, double res, matrix *instrumental) {
	double l, u_mag, alpha, Lambda; // Counters
	int l_below, l_above, u_below, u_above, umax; // Rounded versions of l and u
	int u, ux, uy, i; // u magnitude, x and y
	int fullsize; // Size necessary to get proper resolution
	long idum = (long)time(NULL); // Seed for random number generation
	vector S; // Power spectrum, Fourier series equivalent of observed spherical harmonics (flat-sky approximation)
	matrix a, tmap, output; // Fourier coefficients, output

	//printf("Generating Gaussian map...\n");
	/* Get the right size for resolution */
	fullsize = 2 * size;
	res = res * pow(2.0, 0.5);
	umax = (int)ceil(size * pow(2.0, 0.5) );
	Lambda = res / 10800 * M_PI * size; //10800 arminutes = PI radians. This is for the conversion to get the corect ls.
	
	S = Vector(fullsize);
	a = Matrix(size, size);
	output = Matrix(size, size);
/*Calculating the instrumental noise-coefficient, to be edited to run simulations for specific instruments
	l = 2 * M_PI / Lambda;
	l_below = (int)floor(l);
	l_above = (int)ceil(l);
	alpha = l - (double)l_below;
	coeff = ( Cl.v[l_below][0] + alpha * (Cl.v[l_above][0] - Cl.v[l_below][0]) ) / 4.0 * exp(-4.0); 
	Cl contribution is pow( l/(4 * M_PI * size/Lambda), 2.0) * coeff * exp(pow(l / (4 * M_PI * size/Lambda), 2.0) )
		= pow(umag/(2*umax), 2.0) * coeff * exp(pow(umag/(2*umax), 2.0) )
*/

//Setting Fourier coefficients for 
	for (u = 1; u  <= umax; u++) {
		l = 2 * M_PI * (double)u / Lambda; // l = 2pi/(size*res) (l for arc across the map) *10800/pi (conversion for res in arcminutes) *u,
		l_below = (int)floor(l);
		l_above = (int)ceil(l);
		alpha = l - (double)l_below;
//linear interpolation for l, equation to get Fourier from spherical harmonics
//edited 26/01/2008, suspected error prior, add " /u "
		S.v[u][0] = S.v[u][0] + pow(Cl.v[l_below][0] + alpha * (Cl.v[l_above][0] - Cl.v[l_below][0]), 0.5) / Lambda;
	}

	for (i = 0; i < 4; i++){
	// Produce the Fourier matrix
	for (ux = 0; ux < size; ux++) {
		for (uy = 0; uy < size; uy++) {
			u_mag = pow( (double)ux * (double)ux + (double)uy * (double)uy, 0.5);
			u_below = (int)floor(u_mag);
			u_above = (int)ceil(u_mag);
			alpha = u_mag - (double)u_below;
			a.M[uy + a.n * ux][0] = (S.v[u_below][0] + alpha * 
				(S.v[u_above][0] - S.v[u_below][0])) * gaussian(&idum);
			a.M[uy + a.n * ux][1] = (S.v[u_below][0] + alpha * 
				(S.v[u_above][0] - S.v[u_below][0])) * gaussian(&idum);
		}
	}
	// Get the output by going back to position space
	tmap = Matrix(size, size);

	tmap = invfft2d(a); //Inverse Fourier Transform on the Fourier matrix to produce the map
	/* Finally, symmetrize the map. By symmetrizing along x and y (adding reflections), any systematic assymmetry should be removed. */
	for (ux = 0; ux < output.m; ux++) {
		for (uy = 0; uy < output.n; uy++) {
		//output.M[uy + output.n * ux][0] = tmap.M[uy + tmap.n * ux][0];
		if (i == 0) output.M[uy + output.n * ux][0] = tmap.M[uy + tmap.n * ux][0]/2;
		if (i == 1) output.M[uy + output.n * ux][0] = output.M[uy + output.n * ux][0] + tmap.M[size-1 - uy + tmap.n * ux][0]/2;
		if (i == 2) output.M[uy + output.n * ux][0] = output.M[uy + output.n * ux][0] + tmap.M[uy + tmap.n * (size-1 -ux)][0]/2;
		if (i == 3) output.M[uy + output.n * ux][0] = output.M[uy + output.n * ux][0] + tmap.M[size-1 - uy + tmap.n *(size-1 -ux)][0]/2;

// division by 2: standard deviation (from Cls) is halved because there are 4 gaussian numbers being computed so the results must be doubled. 
	//Using the MLE for sigma here (consider case of 2 maps added together) so dividing by 4 then multiplying by sqrt(4) -> dividing by 2
		}
	}
//	*instrumental = inst(size, umax, res, S);

	fftw_free(tmap.M);
	}

	//*instrumental = Matrix(size, size); // NO INSTRUMENTAL ERROR!!
	fftw_free(a.M);
	fftw_free(S.v);
	//printf("Sucessfully Generated Gaussian Map\n");
	//output = *instrumental; FOR TESTING INSTRUMENTAL ERROR
	breaker;
	return output;
}
// Function to simulate the effects of instrumental error
matrix inst(int size, int umax, double res, vector S){
	double coeff, umag;
	int i, ux, uy;
	matrix fmap, tmap, output;
	long idum = (long)time(NULL); // Seed for random number generation

	fmap = Matrix(size, size);
	output = Matrix(size, size);
	coeff = S.v[umax][0] / (exp( pow(2.0, 0.5) ) * 0.5);
		
	for (i = 0; i < 4; i++){
		for (ux = 0; ux < size; ux++) {
		for (uy = 0; uy < size; uy++) {
		umag = pow( (double)ux * (double)ux + (double)uy * (double)uy, 0.5);
		fmap.M[ux + fmap.m * uy][0] =
			exp( (pow((double)ux* (double)ux + (double)uy* (double)uy, 0.5)) / (pow(0.5, 0.5) * (double)size)) * 			coeff * ((double)ux* (double)ux + (double)uy* (double)uy)/( pow(0.5, 0.5) * (double)size*(double)size ) 			* gaussian(&idum);
		fmap.M[ux + fmap.m * uy][1] =
			exp( (pow((double)ux* (double)ux + (double)uy* (double)uy, 0.5)) / (pow(0.5, 0.5) * (double)size)) * 			coeff * ((double)ux* (double)ux + (double)uy* (double)uy)/( pow(0.5, 0.5) * (double)size*(double)size ) 			* gaussian(&idum);
			}
		}
				
	tmap = invfft2d(fmap);
	
	for (ux = 0; ux < output.m; ux++) {
	for (uy = 0; uy < output.n; uy++) {
		if (i == 0) output.M[uy + output.n * ux][0] = tmap.M[uy + tmap.n * ux][0]/2;
		if (i == 1) output.M[uy + output.n * ux][0] = output.M[uy + output.n * ux][0] + tmap.M[size-1 - uy + tmap.n * ux][0]/2;
		if (i == 2) output.M[uy + output.n * ux][0] = output.M[uy + output.n * ux][0] + tmap.M[uy + tmap.n * (size-1 -ux)][0]/2;
		if (i == 3) output.M[uy + output.n * ux][0] = output.M[uy + output.n * ux][0] + tmap.M[size-1 - uy + tmap.n * (size-1 -ux)][0]/2;
		}
		}
	}

	fftw_free(tmap.M);
	fftw_free(fmap.M);
	return output;	
}

//    --------------CONSIDER THIS ONE------------------ PAST IDEAS (NOT PART OF THE CURRENT VERSION)
	/*a = Matrix(fullsize, fullsize);
	// Finally, deal with the heart of the Fourier matrix
	for (ux = 0; ux < fullsize/2; ux++) {
		for (uy = 0; uy < fullsize/2; uy++) {
		u_mag = pow((double)ux * (double)ux + (double)uy * (double)uy, 0.5);
		u_below = (int)floor(u_mag);
		u_above = (int)ceil(u_mag);
		alpha = u_mag - (double)u_below;
		a.M[uy + a.n * ux][0] = (S.v[u_below][0] + alpha * (S.v[u_above][0] - S.v[u_below][0])) * gaussian(&idum);
		a.M[uy + a.n * ux][1] = (S.v[u_below][0] + alpha * (S.v[u_above][0] - S.v[u_below][0])) * gaussian(&idum);
		a.M[uy + a.n * (fullsize - ux)][0] = (S.v[u_below][0] + alpha * (S.v[u_above][0] - S.v[u_below][0])) * gaussian(&idum);
		a.M[uy + a.n * (fullsize - ux)][1] = (S.v[u_below][0] + alpha * (S.v[u_above][0] - S.v[u_below][0])) * gaussian(&idum);
		a.M[fullsize -1- uy + a.n * (fullsize - ux)][0] = (S.v[u_below][0] + alpha * (S.v[u_above][0] - S.v[u_below][0])) * gaussian(&idum);
		a.M[fullsize -1- uy + a.n * (fullsize - ux)][1] = (S.v[u_below][0] + alpha * (S.v[u_above][0] - S.v[u_below][0])) * gaussian(&idum);
		a.M[fullsize -1- uy + a.n * ux][0] = (S.v[u_below][0] + alpha * (S.v[u_above][0] - S.v[u_below][0])) * gaussian(&idum);
		a.M[fullsize -1- uy + a.n * ux][1] = (S.v[u_below][0] + alpha * (S.v[u_above][0] - S.v[u_below][0])) * gaussian(&idum);
		}
	}
*/
	//output.M[uy + output.n * ux][0]  = (tmap.M[uy + output.n * ux][0] + tmap.M[size+uy + output.n * ux][0] + tmap.M[uy + output.n * (size+ux)][0] + tmap.M[size+uy + output.n * (size+ux)][0])/2;


//	a = Matrix(fullsize, fullsize);

/*
	// Set the top row and left column (ux = 0 and uy = 0) 
	 //The fact that a_u = a_-u * is taken into account 
	for (u = 1; u < (fullsize + 1)/2; u++) {
		a.M[a.n * u][0] = S.v[u][0] * gaussian(&idum);
		a.M[a.n * u][1] = S.v[u][0] * gaussian(&idum);
		a.M[u][0] = S.v[u][0] * gaussian(&idum);
		a.M[u][1] = S.v[u][0] * gaussian(&idum);
		a.M[a.n * (fullsize - u)][0] = a.M[a.n * u][0];
		a.M[a.n * (fullsize - u)][1] = - a.M[a.n * u][1];
		a.M[fullsize - u][0] = a.M[u][0];
		a.M[fullsize - u][1] = - a.M[u][1];
	}

	// If there is an "end" row, set only the terms within a circle of radius
	// fullsize / 2, so as not to have extra bias around the edges
	if (fullsize % 2 == 0) {
		a.M[a.n * fullsize/2][0] = S.v[fullsize/2][0] * gaussian(&idum);
		a.M[fullsize/2][0] = S.v[fullsize/2][0],0.5 * gaussian(&idum);
	}
	// Finally, deal with the heart of the Fourier matrix
	for (ux = 1; ux < fullsize/2; ux++) {
		for (uy = 1; uy < fullsize/2; uy++) {
			u_mag = pow((double)ux * (double)ux + (double)uy * (double)uy, 0.5);
			u_below = (int)floor(u_mag);
			u_above = (int)ceil(u_mag);
			alpha = u_mag - (double)u_below;
			a.M[uy + a.n * ux][0] = (S.v[u_below][0] + alpha * 
				(S.v[u_above][0] - S.v[u_below][0])) * gaussian(&idum);
			a.M[uy + a.n * ux][1] = (S.v[u_below][0] + alpha * 
				(S.v[u_above][0] - S.v[u_below][0])) * gaussian(&idum);
			a.M[uy + a.n * (fullsize - ux)][0] = (S.v[u_below][0] + alpha * 
				(S.v[u_above][0] - S.v[u_below][0])) * gaussian(&idum);
			a.M[uy + a.n * (fullsize - ux)][1] = (S.v[u_below][0] + alpha * 
				(S.v[u_above][0] - S.v[u_below][0])) * gaussian(&idum);
			a.M[fullsize - uy + a.n * (fullsize - ux)][0] = a.M[uy + a.n * ux][0];
			a.M[fullsize - uy + a.n * (fullsize - ux)][1] = - a.M[uy + a.n * ux][1];
			a.M[fullsize - uy + a.n * ux][0] = a.M[uy + a.n * (fullsize - ux)][0];
			a.M[fullsize - uy + a.n * ux][1] = - a.M[uy + a.n * (fullsize - ux)][1];
		}
	}
*/
			/*if (ux < size / 2 && uy < size / 2) {
				output.M[uy + output.n * ux][0] = tmap.M[uy + 3 * fullsize / 4 + 
					tmap.n * (ux + 3 * fullsize / 4)][0];
			}
			else if (ux < size / 2) {
				output.M[uy + output.n * ux][0] = tmap.M[uy - fullsize / 4 + 
					tmap.n * (ux + 3 * fullsize / 4)][0];
			}
			else if (uy < size / 2) {
				output.M[uy + output.n * ux][0] = tmap.M[uy + 3 *  fullsize / 4 + 
					tmap.n * (ux - fullsize / 4)][0];
			}
			else {
				output.M[uy + output.n * ux][0] = tmap.M[uy - fullsize / 4 + 
					tmap.n * (ux - fullsize / 4)][0];
			}*/
