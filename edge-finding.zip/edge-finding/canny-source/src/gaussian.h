#include <time.h>

double gaussian(long *idum);
double rand2(long *idum);
