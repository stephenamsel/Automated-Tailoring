/* powspec.c
 *
 * Function to read the Cl's from a file listed from l = 0 to l = lmax in order
 * seperated by whitespace.  */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "fitsio.h"
#include "global.h"

/* Read the Cl's from input file and store them in an array with proper
 * normalization */
vector readcl(char *filename) {
	vector output; // Output Cl vector
  fitsfile *fptr; // FITS file pointer, defined in fitsio.h
  int status = 0; // CFITSIO status value MUST be initialized to zero
  int hdunum, hdutype; 
	/* Needed to read column type */
	//int coltype;
	//long width;
  long l, nrows;
	double T_cmb;
	float *Cl;
	int lmax;

	if (!fits_open_file(&fptr, filename, READONLY, &status)) {
		if ( fits_get_hdu_num(fptr, &hdunum) == 1 )
			/* This is the primary array;  try to move to the first extension and see 
			 * if it is a table */
      fits_movabs_hdu(fptr, 2, &hdutype, &status);
		else 
			fits_get_hdu_type(fptr, &hdutype, &status); /* Get the HDU type */
		if (hdutype == IMAGE_HDU) 
      printf("Error: cannot read image format\n");
    else {
			fits_read_key(fptr, TDOUBLE, "TCMB", &T_cmb, NULL, &status);
			//fits_get_coltype(fptr, 1, &coltype, &nrows, &width, &status);
			fits_get_num_rows(fptr, &nrows, &status);
			lmax = nrows;
			Cl = (float *)malloc(sizeof(float) * lmax);
			fits_read_col(fptr, TFLOAT, 1, 1, 1, lmax, NULL, Cl, NULL, &status);
			output = Vector(lmax);
			printf("T_cmb = %G\n", T_cmb);
			for (l = 0; l < lmax; l++) {
				output.v[l][0] = (double)Cl[l];
			}
		}
	}
  if (status) fits_report_error(stderr, status); /* print any error message */
	
	return output;
}
