#include <stdio.h>
#include <stdlib.h>
#include "global.h"
#include <math.h>

void mainbreak(){
return;
}

int main(int argc, char *argv[]) {
	
	/* Variable declarations */
	char filename[80];
	double factoravg, factorstdev, juncavg, juncstdev;
	matrix maxima, ipix, filterpixmag, filterpixang, suppressedpix, opix, outmatrix; 
/* Arrays of pixels for stages: maxima is the input map (when input in FITS), ipix is input map (simulated or otherwise), the two filterpix are the magnitude and angles of the gradients after Gaussian filtration, and opix is the final output map */
	imatrix sectormap, sign; 
//directions of gradients, output matrix (for matrix-format output)
	int with_max, inmap, plot_input, plot_output, plot_matrix;
//logicals for whether the program is taking in data, in what format, and which and what formats of maps will be output  
	int i, j, rows, cols;
//counters and #rows and columns in matrix input maps
	int window, multiple, with_strings, with_junc;
//window-size (for simulations), multiple (for testing strings.c and variations), and logicals for whether to include strings and junctions in the model
	double sigma, lower, upper, res, Gmu, nruns, string_p;
//filter, Canny algorithm, and string-model parameters
	int *histograms; //for final output
	double *average, *stddev, *sum2, factor, junc; //factor: for testing and normalization;
	char mapfile[100], mapname[100]; //filenames forinput and output matrix-sets
        double prob_junc;    //input parameter for the probability of junctions	
	char intermediate[80]; // to produce filenames for reading and writing;
	FILE *output, *imap, *outmatfile; //*intermediatedata; //input and output files

	if(argc != 2) {
		printf("Usage: %s <output-file>\n", argv[0]);
		exit(1);
	}
	
	do {
		printf("Use MAXIMA FITS file? ");
	} while (getreply(&with_max));
	getchar();

	do {
		printf("Use externally produced images?");
	} while (getreply(&inmap));
	getchar();
//get specifics on input matrices
	if(inmap){
		printf("Enter path to input maps (without the number):\n");
		scanf("%s", mapfile);
		printf("Enter number of rows per map-segment:\n");
		scanf("%d", &rows);
		window = rows; // to avoid errors later
		printf("Enter number of columns per map-segment:\n");
		scanf("%d", &cols);
	} 
//get filter and algorithm parameters
	printf("Enter the value of sigma for filter: ");
	scanf("%lf", &sigma);
	printf("Enter lower threshold in percentage\n");
	scanf("%lf", &lower);
	printf("Enter upper threshold in percentage\n");
	scanf("%lf", &upper);

//get number of input maps or simulations 
	printf("How many runs shall I make (or maps shall I take)?\n");
	scanf("%lf", &nruns);

//unimplemented possible additions
/*	do {
		printf("Include inflationary anisotropies?\n");
	} while (getreply(&gauss));
	getchar();

	do {
		printf("Include instumental noise?\n");
	} while (getreply(&instrumental));
	getchar();	
*/
//get maps in FITS format
	if (with_max) maxima = readmaxima();
//get data for simulations (image-information and model-information)
	if (with_max == 0 && inmap == 0){
		printf("Enter path to Cl FITS file:\n");
		scanf("%s", filename);

		printf("Enter the window size:");
		scanf("%d", &window);

		printf("Enter the resolution in arcminutes: ");
		scanf("%lf", &res);
	
		do {
			printf("Generate a map with strings? (y|n) ");
		} while (getreply(&with_strings));

		if(with_strings){
			printf("Enter the string tension: ");
			scanf("%lf", &Gmu);

			printf("Enter string probability coefficient:");
			scanf("%lf", &string_p);

			do {
				printf("Make realistic (as opposed to test) simulation?\n");
				} while (getreply(&multiple));

			do {
				printf("Include string junctions?\n");
			} while (getreply(&with_junc));

			if(with_junc){
                          printf("Type in the probability of junctions:\n");
                          scanf("%lf", &prob_junc);
                        }

			} else{
			Gmu = 0.0;
			multiple = 1;
			with_junc = 0;
			string_p = 1.0;
		} // initializing variables, even if not used, to avoid potential errors
	}
	do {
		printf("Plot output maps in matrix format? ");
	} while (getreply(&plot_matrix));

	if(plot_matrix){
		printf("Enter path to output maps (without the number):\n");
		scanf("%s", mapname);
	}

	do {
		printf("Plot output maps in ps format? ");
	} while (getreply(&plot_output));

	do {
		printf("Plot input maps in ps format? ");
	} while (getreply(&plot_input));
	
	factoravg = 0.0;
	factorstdev = 0.0;
	juncavg = 0.0;
	juncstdev = 0.0;
	junc = 0.0;
// One run per map
	for (i = 0; i < nruns; i++) {
// get input map
	
		if (with_max) ipix = maxima;
		else if (inmap) {
					snprintf(intermediate, 80, "%s%d", mapfile, i);
					ipix = Matrix(rows, cols);
					imap = fopen(intermediate, "r");
					for (j = 0; j < rows*cols; j++) fscanf(imap, "%lf", &ipix.M[i][0]);
					fclose(imap);
			if (imap == NULL) {
				fprintf(stderr, "Maps do not comply with required naming conventions.\n Maps must be named: (map set name)_(map number).\n");
				return 0;
			}
		}
		else
			ipix = simulation(window, res, Gmu, string_p, multiple, with_strings, with_junc, filename, prob_junc, i);
	printf("test point 1");
		//printf("Applying Canny algorithm for edge detection...\n");
//Applying filter
		filter(ipix, &filterpixmag, &filterpixang, sigma);
/*Converting gradient-directions from angles to sectors in order to work with them on a grid.
There are 16 sectors, 2 for each of the eight possible directions (right, up/right, up, up/left, left, down/left, down, down/right) on the grid. The 2 possibilities per direction determine whether to check for clockwise or counterclockwise curvature in the string (apparent direction change due to pixel-imprecision or slight deviation in the string) 
Then running the Canny algorithm (suppression, hysteresis)
*/
		mainbreak;
		sectormap = IMatrix(filterpixang.m, filterpixang.n);
		for (i = 0; i < filterpixang.m * filterpixang.n; i++){
			if (filterpixang.M[i][0] < 0.0) filterpixang.M[i][0] = filterpixang.M[i][0] - 22.5; 
/* 22.5 degree are subtracted from negative angles so that the "8" sector is 22.5 degrees like the rest, not 45 */
		sectormap.M[i] = (int)( filterpixang.M[i][0] / 22.5 ) + 8;
		}
//Submaximal suppression
		suppressedpix = maxsuppression(filterpixmag, filterpixang);
//Always free any big arrays created inside the main loop, or there will be memory-issues
		fftw_free(filterpixmag.M);
		fftw_free(filterpixang.M);
//producing the ouput map
		opix = hysteresis(suppressedpix, sectormap, lower, upper, sigma, res, &factor);

		fftw_free(suppressedpix.M);

//Plotting input and output maps as images in Postscript format, if desired
		if (plot_input){
/*"intermediate" is the filename of the plotted input. Because it depends on the run-number, each map does not overwrite the previous one. */
			if (inmap){
			snprintf(intermediate, 80, "%s-out-sig:%G-low:%G-up:%G-size:%d-run:%i.ps", mapfile,sigma,lower,upper,window,i);
			}else snprintf(intermediate, 80, "out-sig:%G-low:%G-up:%G-size:%d-res:%G-Gmu:%G-run:%i.ps", sigma,lower,upper,window,res,Gmu,(int)i);
			
/*		intermediatedata = fopen("canny_outputs/in_filename.txt", "w");
		fprintf(intermediatedata, "in-sig:%G-low:%G-up:%G-size:%d-res:%G-Gmu:%G-run:%d", sigma,lower,upper,window,res,Gmu,i);
		rewind (intermediatedata);
		fclose(intermediatedata); */
			psplot(ipix, 'a', intermediate);
		}

		if (plot_output){
			if (inmap) {
				snprintf(intermediate, 80, "%s-in-sig:%G-low:%G-up:%G-size:%d-run:%i.ps", mapname,sigma,lower,upper,window,i);
			} else snprintf(intermediate, 80, "in-sig:%G-low:%G-up:%G-size:%d-res:%G-Gmu:%G-run:%d.ps", sigma,lower,upper,window,res,Gmu,i);
/*		intermediatedata = fopen("canny_outputs/out_filename.txt", "w");
		fprintf(intermediatedata, "out-sig:%G-low:%G-up:%G-size:%d-res:%G-Gmu:%G-run:%d.ps", sigma,lower,upper,window,res,Gmu,i);
		rewind (intermediatedata);
		fclose(intermediatedata); */
			psplot(opix, 'b', intermediate);
		}

//writing output matrix, if desired
		if (plot_matrix){
			snprintf(intermediate, 80, "canny_outputs/%s%d", mapname, i);
			outmatfile = fopen(intermediate, "w");
//			outmatrix = Matrix(ipix.m, ipix.n); for testing matrix-input
			outmatrix = Matrix(opix.m, opix.n);

			for (j = 0; j < opix.m * opix.n; j++){
			//	outmatrix.M[j][0] = ipix.M[j][0]; for testing
				if (opix.M[j][0]) outmatrix.M[j][0] = sectormap.M[j];
			//	fprintf(outmatfile, "%g ", outmatrix.M[j][0]); for testing
				fprintf(outmatfile, "%d ", (int)outmatrix.M[j][0]);
				if (j % outmatrix.n-1 == 0 && j !=0) fprintf(outmatfile, "\n");
			}
			fclose(outmatfile);
			fftw_free(outmatrix.M);
		}

		histograms = (int *)malloc(sizeof(int) * (opix.n + 1));
/*Using the results of the algorithm to count the mean number of edges detected of each length and the standard deviation of number of each length. These are the contents ofthe histogram. */
		stringcount(opix, histograms, &junc, sectormap);
		if (i == 0) {
			average = (double *)malloc(sizeof(double) * (opix.n + 1));
			sum2 = (double *)malloc(sizeof(double) * (opix.n + 1));
		}
		for (j = 0; j <= opix.n; j++) {
			if (i == 0) {
				average[j] = (double)histograms[j];
				sum2[j] = (double)histograms[j] * (double)histograms[j];
			}
			else {
				average[j] = ((double)i * average[j] + (double)histograms[j]) / ((double)i + 1);
				sum2[j] = sum2[j] + (double)histograms[j] * (double)histograms[j];
			}
		}

		//printf("Successfully applied Canny algorithm\n");
//Preventing memory problems (which would be large enough to cause user-problems due to irate sysadmin)
		fftw_free(ipix.M);
		fftw_free(opix.M);
		fftw_free(sectormap.M);
		free(histograms);

/*Factor for normalization. In the general case, this just reports the maximum gradient and its standard devation. This data is tabulated for simulations so that when comparing models, the maximum power can be normalized and maintained. This is important because the canny algorithm parameters are expressed as a percent of the maximum power, so if this changes, so does the meaning of the parameters.
For example, the gradients around cosmic strings would raise the maximum so that the thresholds used would be raised and miss some edges and false positives. This leads to fewer edges detected when there is a small number of sharp (easily visible) edges, distorting the histogram-data.
*/
		factoravg = factoravg + factor;
		factorstdev = factorstdev + factor * factor / nruns;
		juncavg = juncavg + junc/nruns;
		juncstdev = juncstdev + junc * junc / nruns;
	}
	factoravg = factoravg / nruns;
	factorstdev = pow((factorstdev - factoravg * factoravg)/(nruns-1), 0.5);
	printf("\n STANDARD DEVIATION OF THE NORMALIZATION FACTOR: %g \n", factorstdev);
	printf("AVERAGE NORMALIZATION FACTOR: %g \n", factoravg); 
	
	stddev = (double *)malloc(sizeof(double) * (opix.n + 1));
	output = fopen(argv[1], "w");
	fprintf(output, "\t%6.10G\t%6.10G\n", juncavg, juncstdev);
	for (j = 0; j <= opix.n; j++) {
		stddev[j] = sqrt((sum2[j] - (double)nruns * average[j] * average[j]) / ((double)nruns - 1));
		fprintf(output, "%5d\t%6.10G\t%6.10G\n", j, average[j], stddev[j]);
	}
	fclose(output);
	return 0;
}
