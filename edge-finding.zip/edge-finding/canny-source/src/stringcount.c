#include <stdio.h>
#include <math.h>
#include <time.h>
#include "gaussian.h"
#include "global.h"

/*
This module begins with "stringcount" which cycles through all points on the output map ("map"). 
In cases which may be on strings and fit criterea such that they may be starting points for strings (detailed above "firstpoint"), it then begins a loop of the other functions described below:

"countpoint" checks for directional agreement as required by "diragree". 
	Current requirements include variation by no more than 1 sector from the previous point on the suspected string, and also from the point before that. An exception to this limit on curvature is the second point considered, as there is no "point before that". If there is agreement, it raises the length-of-string-to-be-reported and calls branchtest. Otherwise it returns to the function that called it.

"branchtest" calls both counthorvert and countdiag, accounting for the possibility of a change of direction or branchoff in the string. In the case of a branchoff, it takes the longer branch to be the continuation counts the shorter as a new string which just happens to connect. Where there is no branchoff,  the "shorter string" is of 0 length so both cases can be handled indentically. String lengths are recorded here in the histogram. A count could be added here if the number of branchoffs is to be studied.
	
"counthorvert" and "countdiag" each consider one of the possible next points for continuation of the string. For each sector there are two possible directions, one vertical or horizontal, and one diagonal. Each function determines one possibility based on the sector and on the previous point considered. For example, for a point following a sector 4 point approached from the left would be either directly to the right or up and to the right. It then calls "countpoint" to check the new point, restarting the loop.
	
The starting point criterea  in "firstpoint" demand that there not be another point "on a string" which has "directional agreement" to the tested point on one of its "sides". Each "side" consists of two directions, one horizontal or vertical, and one diagonal. The "side" of approach determines the next point to be considered. Thus the point must not have been considered previously from that direction. This leaves out strings starting at points that could be approached from a previous point but not points before that (so the branchoff length would be 0). This is handled under "endpoint".

The "endpoint" failsafe prevents double-counting by marking the ends of any formation of string and branchoffs. 
	If a newly considered string ends at the same endpoints as an old one it is not counted.
	The endpoint matrix is also used for a special case where the starting point criterea would lead to non-counting:
	The appropriate points are flagged on this matrix and automatically made into starting points.
	POSSIBLE ERROR: The point might not be flagged before it is considered. Then the corresponding string would not be counted.

A quick recap of sectors:	Gradient directions				Perpendicular to gradient (sector X is equivalent to sector X+8)
					  12 11						 0 7
				        13      10				        1    6
				      14         9				       2      5
				    15            8				      3        4
				     0	          7				      4        3
				      1         6				       5      2
					2     5					        6    1
					  3 4						 7 0

*/

/*
I realize that the orders are different and this can be confusing. Sorry about that. I will try to fix it later.
*/

void countbreak(){
return;
}

void countpoint(imatrix isec, matrix map, matrix endpoints, int prea, int preb, int a, int b,  int q, int r, int *histogram, int *length, int edgenumber, int start);
void branchtest(imatrix isec, matrix map, matrix endpoints, int prea, int preb, int a, int b, int *histogram, int *length, int edgenumber, int start);
void counthorvert(int prea, int preb, imatrix isec, matrix map, matrix endpoints, int a, int b, int *histogram, int *length, int edgenumber, int start);
void countdiag(int prea, int preb, imatrix isec, matrix map, matrix endpoints, int a, int b, int *histogram, int *length, int edgenumber, int start);
int firstpoint(int i, int j, matrix map, imatrix isec, matrix endpoints);

void stringcount(matrix map, int *histogram, double *junc, imatrix isec) {
	int i, j, *length, edgenumber;
	matrix juncmap, endpoints;
	edgenumber = 0;	
	juncmap = Matrix(map.m, map.n);
	endpoints = Matrix(map.m, map.n);

	//printf("Counting Strings...\n");

	for (i = 0; i <= (int)(sqrt((double)(map.m * map.m + map.n * map.n) + 1.0)); i++) {
		histogram[i] = 0;
	}
countbreak;
	for (i = 0; i < map.n; i++){
		for (j = 0; j <= map.m; j++){
			if (map.M[i * map.m + j][0] == 1 && firstpoint(i, j, map, isec, endpoints) == 1){
			edgenumber++;
			endpoints.M[i*map.m + j][0] = edgenumber;
                        *length = 0;
			countpoint(isec, map, endpoints, i, j, i, j, i, j, histogram, length, edgenumber, j + i*map.n);
			}
		}
	}
	return;
}
/*
Criterea for a starting point to prevent double-counting from running the same line repeatedly from different points.
NOTE: Not strictly necessary. Endpoints would prevent double-counting, but relying on that alone would leave a ridiculous runtime.
Note: x = 0 OR y = 0 <-> x * y = 0
As i, j, and map.M[] values are non-negative, x = 0 AND y = 0 <-> x + y = 0
*/
int firstpoint(int i, int j, matrix map, imatrix isec, matrix endpoints){
	int out = 0;
	if ( (isec.M[j + i*map.m]) % 8 < 2 &&
		(i * map.M[(i-1) * map.m + j][0] +
		j * i * map.M[(i-1) * map.m + j-1][0] == 0) ){
			out = 1;
		}else if ( (isec.M[j + i*map.m]) % 8 <4 &&
		(j * map.M[i * map.m + j-1][0] +
		j * i * map.M[(i-1) * map.m + j-1][0] == 0)
		){
			out = 1;
		}else if ( (isec.M[j + i*map.m]) % 8 <6 &&
		(j * map.M[i * map.m + j-1][0] +
		(j - map.m) * (i - map.n) * map.M[(i+1) * map.m + j-1][0] == 0)
		){
			out = 1;
		}else if (i * map.M[(i-1) * map.m + j][0] +
		(j - map.m) * i * map.M[(i-1) * map.m + j+1][0] == 0){
			out = 1;
		}
	if (endpoints.M[j + i*map.m][1] == 0.5) out = 1;
	return out;
}

void countpoint(imatrix isec, matrix map, matrix endpoints, int prea, int preb, int a, int b,  int q, int r, int *histogram, int *length, int edgenumber, int start){
	if (r < map.n && r >= 0 && q < map.m && q >= 0){
		if (diragree(isec, b + a*map.n, r + q*map.n) && map.M[r + q*map.m][0] > 0){
			if (diragree(isec, preb + prea*map.n, r + q*map.m) == 1){
			*length++;
			branchtest(isec, map, endpoints, a, b, q, r, histogram, length, edgenumber, start);
			} else {
				endpoints.M[r + q*map.m][1] = 0.5;
		/*
		If the new point matches the previous one but not the one before it, it would otherwise not be counted
		either as a branchoff or a starting point (in firstpoint). It may be a starting point, and if it is not,
		the "endpoints" failsafe will cause the resulting line not to be counted.
		*/
			}
		}
	}
	return;
}

void branchtest(imatrix isec, matrix map, matrix endpoints, int prea, int preb, int a, int b, int *histogram, int *length, int edgenumber, int start){
	int *lengthone, *lengthtwo;
	*lengthone = 0; // for horizontal or vertical branch
	*lengthtwo = 0; // for diagonal branch
	
	counthorvert(prea, preb, isec, map, endpoints, a, b, histogram, lengthone, edgenumber, start);
	countdiag(prea, preb, isec, map, endpoints, a, b, histogram, lengthtwo, edgenumber, start);
	if (lengthone > lengthtwo) histogram[*length + *lengthone] ++;
	if (lengthone <= lengthtwo) histogram[*length + *lengthtwo] ++;
	if (*lengthone + *lengthtwo == 0 && (endpoints.M[b + a*map.m][0] != endpoints.M[start][0] || endpoints.M[b + a*map.m][0] == 0) ){
		endpoints.M[b + a*map.m][0] = edgenumber;
		if (*length < map.n + 1){
			histogram[*length]++;
	        }else{
			histogram[map.n]++;
		}
	}
//	free(&a); free(&b); free(&lengthone); free(&lengthtwo);

	return;
}
/*
The "counthorvert" and "countdiag" functions work similarly to the analogous functions in the hysteresis.
The difference in form is that they are voids with the length changed in them rather than functions returning the desired information.
In terms of function, these are used to determine where to continue the count rather than where to test for connection to a point above the upper threshold.
*/
void counthorvert(int prea, int preb, imatrix isec, matrix map, matrix endpoints, int a, int b, int *histogram, int *length, int edgenumber, int start){
	int q, r;
	if((isec.M[b + a*map.m]) % 8 > 1 && (isec.M[b + a*map.m] ) % 8 < 6){
		if (preb >= b){
			r = b - 1;
			q = a;
			countpoint(isec, map, endpoints, prea, preb, a, b, q, r, histogram, length, edgenumber, start);
		}
		if (preb <= b){
			r = b + 1;
			q = a;
			countpoint(isec, map, endpoints, prea, preb, a, b, q, r, histogram, length, edgenumber, start);
		}
	} else{
		if (prea >= a){
			q = a - 1;
			r = b;
			countpoint(isec, map, endpoints, prea, preb, a, b, q, r, histogram, length, edgenumber, start);
		}
		if (prea <= a){
			q = a + 1;
			r = b;
			countpoint(isec, map, endpoints, prea, preb, a, b, q, r, histogram, length, edgenumber, start);
		}
	}
//	free(q); free(r);
	return;
}

void countdiag(int prea, int preb, imatrix isec, matrix map, matrix endpoints, int a, int b, int *histogram, int *length, int edgenumber, int start){
	int q, r;
	if ((isec.M[b + a*map.m]) % 8 < 4){
		if (a+b <= prea+preb && a > 0 && b > 0){
			q = a - 1; 
			r = b - 1;
			countpoint(isec, map, endpoints, prea, preb, a, b, q, r, histogram, length, edgenumber, start);
		}
		if (a+b >= prea+preb && a < map.n && b < map.m){
			q = a + 1;
			r = b + 1;
			countpoint(isec, map, endpoints, prea, preb, a, b, q, r, histogram, length, edgenumber, start);
		}
	}else {
		if (a-b <= prea-preb && a > 0 && b < map.m){
			q = a - 1; 
			r = b + 1;
			countpoint(isec, map, endpoints, prea, preb, a, b, q, r, histogram, length, edgenumber, start);
		}
		if (a-b >= prea-preb && a < map.n && b > 0){
			q = a + 1;
			r = b - 1;
			countpoint(isec, map, endpoints, prea, preb, a, b, q, r, histogram, length, edgenumber, start);
		}
	}
//	free(q); free(r);
	return;
}
