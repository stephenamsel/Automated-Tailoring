#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "global.h"

matrix maxsuppression(matrix imag, matrix iang) {
	int i, j;
	matrix output;
	double gradient1, gradient2;
	
	output = Matrix(imag.m, imag.n);
	for (i = 0; i < output.m; i++) {
		for (j = 0; j < output.n; j++) {
			if ((iang.M[j + i*iang.n][0] >= 0 && iang.M[j + i*iang.n][0] <= 45) ||
					(iang.M[j + i*iang.n][0] > -180 && iang.M[j + i*iang.n][0] <= -135)) {
				if (i > 0 && j < imag.n - 1)
					gradient1 = imag.M[j+1 + i*imag.n][0] + 
						tan(iang.M[j + i*iang.n][0] * M_PI / 180.0) *
						(imag.M[j+1 + (i-1)*imag.n][0] - imag.M[j+1 + i*imag.n][0]); 
				else
					gradient1 = 0.0;
				if (i < imag.m - 1 && j > 0)
					gradient2 = imag.M[j-1 + i*imag.n][0] + 
						tan(iang.M[j + i*iang.n][0] * M_PI / 180.0) *
						(imag.M[j-1 + (i+1)*imag.n][0] - imag.M[j-1 + i*imag.n][0]);
				else
					gradient2 = 0.0;
			}
			else if ((iang.M[j + i*iang.n][0] > 45 && iang.M[j + i*iang.n][0] <= 90) 
					|| (iang.M[j + i * iang.n][0] > -135 && 
						iang.M[j + i * iang.n][0] <= -90)) {
				if (i > 0 && j < imag.n - 1)
					gradient1 = imag.M[j+1 + (i-1)*imag.n][0] + 
						tan((iang.M[j + i*iang.n][0] - 45.0) * M_PI / 180.0) *
						(imag.M[j + (i-1)*imag.n][0] - imag.M[j+1 + (i-1)*imag.n][0]); 
				else
					gradient1 = 0.0;
				if (i < imag.m - 1 && j > 0)
					gradient2 = imag.M[j-1 + (i+1)*imag.n][0] + 
						tan((iang.M[j + i*iang.n][0] - 45.0) * M_PI / 180.0) *            
						(imag.M[j + (i+1)*imag.n][0] - imag.M[j-1 + (i+1)*imag.n][0]);
				else
					gradient2 = 0.0;
			}
			else if ((iang.M[j + i*iang.n][0] > 90 && iang.M[j + i*iang.n][0] <= 135) 
					|| (iang.M[j + i * iang.n][0] > -90 && 
						iang.M[j + i * iang.n][0] <= -45)) {
				if (i > 0 && j > 0)
					gradient1 = imag.M[j + (i-1)*imag.n][0] +
						tan((iang.M[j + i*iang.n][0] - 90.0) * M_PI / 180.0) *
						(imag.M[j-1 + (i-1)*imag.n][0] - imag.M[j + (i-1)*imag.n][0]); 
				else
					gradient1 = 0.0;
				if (i < imag.m - 1 && j < imag.n - 1)
					gradient2 = imag.M[j + (i+1)*imag.n][0] +
						tan((iang.M[j + i*iang.n][0] - 90.0) * M_PI / 180.0) *            
						(imag.M[j+1 + (i+1)*imag.n][0] - imag.M[j + (i+1)*imag.n][0]);
				else
					gradient2 = 0.0;
			}
			else {
				if (i > 0 && j > 0)
					gradient1 = imag.M[j-1 + (i-1)*imag.n][0] + 
						tan((iang.M[j + i*iang.n][0] - 135.0) * M_PI / 180.0) *
						(imag.M[j-1 + i*imag.n][0] - imag.M[j-1 + (i-1)*imag.n][0]); 
				else
					gradient1 = 0.0;
				if (i < imag.m - 1 && j < imag.n - 1)
					gradient2 = imag.M[j+1 + (i+1)*imag.n][0] +
						tan((iang.M[j + i*iang.n][0] - 135.0) * M_PI / 180.0) *            
						(imag.M[j+1 + i*imag.n][0] - imag.M[j+1 + (i+1)*imag.n][0]);
				else
					gradient2 = 0.0;
			}
			if (imag.M[j + i*imag.n][0] >= gradient1 && 
					imag.M[j + i*imag.n][0] >= gradient2) {
				output.M[j + i*output.n][0] = imag.M[j + i*imag.n][0];
			}
		}
	}
	return output;
}
