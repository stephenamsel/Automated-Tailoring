#include <stdio.h>
#include <stdlib.h>
#include "global.h"
#include <math.h>

void mainbreak(){
//For setting breakpoints in SCiTE
return;
}

int main(int argc, char *argv[]) {
	
	/* Variable declarations */
	char filename[80];
	double factoravg, factorstdev, juncavg, juncstdev;
	matrix maxima, ipix, filterpixmag, filterpixang, suppressedpix, opix, outmatrix; 
/* Arrays of pixels for stages: maxima is the input map (when input in FITS), ipix is input map (simulated or otherwise), the two filterpix are the magnitude and angles of the gradients after Gaussian filtration, and opix is the final output map */
	imatrix sectormap, sign; 
//directions of gradients, output matrix (for matrix-format output)
	int with_max, inmap, plot_input, plot_output, plot_matrix;
//logicals for whether the program is taking in data, in what format, and which and what formats of maps will be output  
	int i, j, k, rows, cols;
//counters and #rows and columns in matrix input maps
	int window, multiple, with_strings, with_junc;
//window-size (for simulations), multiple (for testing strings.c and variations), and logicals for whether to include strings and junctions in the model
	double sigma, lower, upper, res, Gmu, string_p;
//filter, Canny algorithm, and string-model parameters
	int *histograms, nruns; //for final output
	double *average, *stddev, *sum2, factor, junc; //factor: for testing and normalization;
	char mapfile[100], mapname[100]; //filenames forinput and output matrix-sets
        double thetac;    //input parameter for the probability of junctions	
	char intermediate[80]; // to produce filenames for reading and writing;
	FILE *output, *imap, *outmatfile; //*intermediatedata; //input and output files

/*	if(argc != 2) {
		printf("Usage: %s <output-file>\n", argv[0]);
		exit(1);
	}
*/	
//	do {
//		printf("Use MAXIMA FITS file? ");
//	} while (getreply(&with_max));
//	getchar();
	with_max = 0;
	
//	do {
//		printf("Use externally produced images?");
//	} while (getreply(&inmap));
//	getchar();
	inmap = 0;
	
//get specifics on input matrices
	if(inmap){
		printf("Enter path to input maps (without the number):\n");
		scanf("%s", mapfile);
		printf("Enter number of rows per map-segment:\n");
		scanf("%d", &rows);
		window = rows; // to avoid errors later
		printf("Enter number of columns per map-segment:\n");
		scanf("%d", &cols);
	} 
//get filter and algorithm parameters


	printf("Enter the value of sigma for filter, lower canny-bound, upper canny-bound: ");
	scanf("%lf %lf %lf", &sigma,&lower,&upper);

//	sigma = 1.25;
//	lower = 40;
//	upper = 60;

//get number of input maps or simulations 
	printf("How many runs shall I make (or maps shall I take)?\n");
	scanf("%d", &nruns);

//	nruns = 5;
//unimplemented possible additions
/*	do {
		printf("Include inflationary anisotropies?\n");
	} while (getreply(&gauss));
	getchar();

	do {
		printf("Include instumental noise?\n");
	} while (getreply(&instrumental));
	getchar();	
*/
//get maps in FITS format
//	if (with_max) maxima = readmaxima();
//get data for simulations (image-information and model-information)
	if (with_max == 0 && inmap == 0){
//		printf("Enter path to Cl FITS file:\n");
//		sscanf("asciicls", filename);

		printf("Enter the window size in pixels and resolution in arcminutes/pixel:");
		scanf("%d %lf", &window, &res);

//		window = 30;
//		res = 25;
//		printf("Enter the resolution in arcminutes: ");
//		scanf("%lf", &res);
		with_strings = 0;
		Gmu = 0;
		string_p = 0;
		thetac = 0;
		do {
			printf("Generate a map with circles? (y|n) ");
		} while (getreply(&with_strings));

		if(with_strings){
			printf("Enter circle-heat: ");
			scanf("%lf", &Gmu);

			printf("Enter number of circles in simulated region:");
			scanf("%lf", &string_p);
/* For testing simulation of new signals
			do {
				printf("Make realistic (as opposed to test) simulation?\n");
				} while (getreply(&multiple));
			do {
				printf("Include string junctions?\n");
			} while (getreply(&with_junc));
*/			
                          printf("Enter radius of circles in degrees on sky:\n");
                          scanf("%lf", &thetac);

			} else{
//			Gmu = 0.0;
			multiple = 1;
			with_junc = 0;
			//string_p = 1.0; //Used for Cosmic String benchmarking, not Eternal Inflation
		} // initializing variables, even if not used, to avoid potential errors
	}

	plot_matrix = 1;

	if(plot_matrix){
		printf("Enter path to output maps (without the number):\n");
		scanf("%s", mapname);
	} 

//The matrix is now the central input for the Matlab algorithmm which produces better outputs than the originals.
/*	do {
		printf("Plot output maps in matrix format? ");
	} while (getreply(&plot_matrix)); 

	sscanf("test", mapname);
	do {
		printf("Plot output maps in ps format? ");
	} while (getreply(&plot_output));

	do {
		printf("Plot input maps in ps format? ");
	} while (getreply(&plot_input));
*/	
	factoravg = 0.0;
	factorstdev = 0.0;
	juncavg = 0.0;
	juncstdev = 0.0;
	junc = 0.0;
	mainbreak;
// One run per map
	for (k = 0; k < nruns; k++) {

//Benchmark testing uses statistically correct simulated images rather than real data
/*
// get input map
		if (with_max) ipix = maxima;
		else if (inmap) {
				snprintf(intermediate, 80, "%s%d", mapfile, i);
				ipix = Matrix(rows, cols);
				imap = fopen(intermediate, "r");
				for (j = 0; j < rows*cols; j++) fscanf(imap, "%lf", &ipix.M[i][0]);
				fclose(imap);
			if (imap == NULL) {
				fprintf(stderr, "Maps do not comply with required naming conventions.\n Maps must be named: (map set name)_(map number).\n");
				return 0;
			}
		}
		else

*/	mainbreak;
//	printf("test point %d \n", k); //Left over from testing and debugging. Good to have for future modification.
			ipix = simulation(window, res, Gmu, string_p, multiple, with_strings, with_junc, filename, thetac, i);
//	printf("test point 1");
		//printf("Applying Canny algorithm for edge detection...\n");
//Applying filter
		filter(ipix, &filterpixmag, &filterpixang, sigma);
/*Converting gradient-directions from angles to sectors in order to work with them on a grid.
There are 16 sectors, 2 for each of the eight possible directions (right, up/right, up, up/left, left, down/left, down, down/right) on the grid. The 2 possibilities per direction determine whether to check for clockwise or counterclockwise curvature in the string (apparent direction change due to pixel-imprecision or slight deviation in the string) 
Then running the Canny algorithm (suppression, hysteresis)
*/
		mainbreak;
		sectormap = IMatrix(filterpixang.m, filterpixang.n);
		for (i = 0; i < filterpixang.m * filterpixang.n; i++){
			if (filterpixang.M[i][0] < 0.0) filterpixang.M[i][0] = filterpixang.M[i][0] - 22.5; 
/* 22.5 degree are subtracted from negative angles so that the "8" sector is 22.5 degrees like the rest, not 45 */
		sectormap.M[i] = (int)( filterpixang.M[i][0] / 22.5 ) + 8;
		}
//Submaximal suppression
		suppressedpix = maxsuppression(filterpixmag, filterpixang);
//Always free any big arrays created inside the main loop, or there will be memory-issues
		fftw_free(filterpixmag.M);
		fftw_free(filterpixang.M);
//producing the ouput map
		opix = hysteresis(suppressedpix, sectormap, lower, upper, sigma, res, &factor);

		fftw_free(suppressedpix.M);

//Plotting input and output maps as images in Postscript format, if desired
		if (plot_input){
/*"intermediate" is the filename of the plotted input. Because it depends on the run-number, each map does not overwrite the previous one. */
			if (inmap){
			snprintf(intermediate, 80, "%s-in-sig:%G-low:%G-up:%G-size:%d-run:%i.ps", mapfile,sigma,lower,upper,window,k);
			}else snprintf(intermediate, 80, "in-sig:%G-low:%G-up:%G-size:%d-res:%G-Gmu:%G-run:%i.ps", sigma,lower,upper,window,res,Gmu,(int)k);
			psplot(ipix, 'a', intermediate);
		}

//Native output no longer used. 
/*"
intermediatedata" is a very slow but extremely versatile and scalable way of passing global information during development.
It is used to see what values are getting passed around in the code, useful during development and debugging, but to be removed before production.
*/
/*		if (plot_output){
			if (inmap) {
				snprintf(intermediate, 80, "%s-out-sig:%G-low:%G-up:%G-size:%d-run:%i.ps", mapname,sigma,lower,upper,window,k);
			} else snprintf(intermediate, 80, "out-sig:%G-low:%G-up:%G-size:%d-res:%G-Gmu:%G-run:%d.ps", sigma,lower,upper,window,res,Gmu,k);

		intermediatedata = fopen("canny_outputs/out_filename.txt", "w");
		fprintf(intermediatedata, "out-sig:%G-low:%G-up:%G-size:%d-res:%G-Gmu:%G-run:%d.ps", sigma,lower,upper,window,res,Gmu,i);
		rewind (intermediatedata);
		fclose(intermediatedata);
			psplot(opix, 'b', intermediate);
		}
*/

//writing output matrix, if desired
		if (plot_matrix){
			snprintf(intermediate, 80, "canny_outputs/%s%d", mapname, k);
			outmatfile = fopen(intermediate, "w");
//			outmatrix = Matrix(ipix.m, ipix.n); for testing matrix-input
			outmatrix = Matrix(opix.m, opix.n);

			for (j = 0; j < opix.m * opix.n; j++){
			//	outmatrix.M[j][0] = ipix.M[j][0]; for testing
				if (opix.M[j][0]) outmatrix.M[j][0] = sectormap.M[j]+1;
			//	fprintf(outmatfile, "%g ", outmatrix.M[j][0]); for testing
				fprintf(outmatfile, "%d ", ((int)outmatrix.M[j][0]-1));
				if ((j+1) % outmatrix.n == 0) fprintf(outmatfile, "\n");
			}
			fclose(outmatfile);
			fftw_free(outmatrix.M);

			snprintf(intermediate, 80, "canny_outputs/%s%d_input", mapname, k);
			outmatfile = fopen(intermediate, "w");
//			outmatrix = Matrix(ipix.m, ipix.n); for testing matrix-input


			for (j = 0; j < opix.m * opix.n; j++){
				fprintf(outmatfile, "%g ", ipix.M[j][0]);
			//	fprintf(outmatfile, "%d ", ((int)outmatrix.M[j][0]-1));
				if ((j+1) % ipix.n == 0) fprintf(outmatfile, "\n");
			}
			fclose(outmatfile);
		}


		fftw_free(ipix.M);
		fftw_free(opix.M);
		fftw_free(sectormap.M);
//		free(histograms);
}
	return 0;
}
