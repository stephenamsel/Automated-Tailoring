clear global outmap
clear global sector
clear global edgenumber
clear global endpoints
clear global histogram

load sectormap

global outmap sector edgenumber endpoints histogram,

%padding maps with zeros to avoid running past end of arrays
outmap = zeros(size(sectormap,1)+2,size(sectormap,2)+2);
sector = zeros(size(sectormap,1)+2,size(sectormap,2)+2);
for i=1:size(sectormap,1)
    for j=1:size(sectormap,2)
       if sectormap(i,j) > -1
          outmap(i+1,j+1)=1;
       end
       sector(i+1,j+1)=sectormap(i,j);
    end
end

edgenumber = 0;
endpoints = zeros(size(sector));
histogram = zeros(100,1); %#ok<NASGU>
dist = 0;
for i=2:size(sector,1)
   for j=2:size(sector,2)
       first = firstpoint(i,j);
       if outmap(i,j) == 1 && first==1
            edgenumber = edgenumber + 1;
            
            dist = 0;
            
            countpoint(i,j,i,j,dist);
       end
   end
end
   histogram'